# =====================================================================
#  SAFECLIC - HISTORIA 2: "Una clave para todo"
#  Tema: contraseñas seguras, verificación en dos pasos y robo de cuentas
#  Archivo: game/historia2.rpy   (guardar en UTF-8)
#
#  Se juega desde menu_principal.rpy con "call historia2".
#  Personajes, fondos, transform y variables compartidas: comun.rpy
# =====================================================================

# --- Variables de esta historia ---
default avisaste_pronto  = False   # avisó a sus contactos desde el inicio
default sofia_afectada   = False   # Sofía llegó a abrir el link
default correo_asegurado = False   # protegió el correo esa misma noche
default clave_fuerte     = False
default dos_pasos        = False
default claves_distintas = False


label historia2:

    # Reinicia el estado por si la historia se juega más de una vez
    $ puntos = 0
    $ avisaste_pronto = False
    $ sofia_afectada = False
    $ correo_asegurado = False
    $ clave_fuerte = False
    $ dos_pasos = False
    $ claves_distintas = False

    # Si la historia 1 ya pidió el nombre, esto se salta solo
    if nombre_jugador == "":
        $ nombre_jugador = renpy.input("Antes de empezar, ¿cómo te llamas?", length=14).strip()
        if nombre_jugador == "":
            $ nombre_jugador = "Alex"

    scene black 
    centered "{size=+8}Historia 2{/size}\n{b}Una clave para todo{/b}"

    scene bg cuarto with fade
    # play music "audio/noche_tranquila.ogg" fadein 1.0

    narrador "Domingo, casi las diez de la noche. Mañana hay prueba de Matemática y yo, como siempre, estoy repasando a última hora... con el celular al lado, por supuesto."
    narrador "Vibra una vez. Luego otra. Luego ya no para."

    show celular:
        zoom 0.5
        xalign 0.5
        yalign 0.5

    chat "Valeria: ¿fuiste tú quien mandó ese link al grupo?"
    chat "Valeria: se ve raro, no lo abrí"
    chat "Mateo: [nombre_jugador], ¿qué es esto? Me pide la clave para ver unas fotos tuyas"
    chat "Sofía: ¿QUÉ ES ESO?? contesta"

    yo "¿Qué link? Yo no mandé nada..."
    narrador "Abro la app para revisar. En lugar de mi perfil, aparece la pantalla de inicio de sesión."
    narrador "«La contraseña es incorrecta»."
    yo "Imposible. Es mi clave de siempre."

    menu:
        "Mi cuenta está mandando ese link a mis contactos. ¿Qué hago primero?"

        "Intentar entrar de nuevo, rapido":
            narrador "Pruebo mi clave de siempre. Nada. Pruebo una variación. Nada."
            narrador "Tercer intento: «Demasiados intentos. Inténtalo más tarde»."
            yo "Genial. Ahora ni siquiera puedo intentarlo."
            narrador "El celular sigue vibrando sobre el escritorio. Cada vibración es alguien más que puede estar abriendo ese link."

        "Avisar a mis contactos por otro lado, antes de que alguien abra el link":
            $ avisaste_pronto = True
            $ puntos += 1
            narrador "Abro el chat del curso, el que tiene a todo el salón, y escribo con los pulgares temblando."
            chat "Yo: No abran NINGÚN link que salga de mi cuenta. Me la hackearon. No pongan su clave en ningún lado. Ya les cuento."
            chat "Valeria: ya lo reporté, gracias por avisar"
            chat "Mateo: bien hecho. Calmate, te llamo ahora"
            hide celular

    jump h2_llamada


# =====================================================================
#  LA LLAMADA CON MATEO
# =====================================================================
label h2_llamada:

    scene bg cuarto oscuro with dissolve
    
    narrador "Sin darme cuenta apagué la luz del escritorio. Solo queda el brillo de la pantalla en mi cara."
    narrador "Entra una llamada. Es Mateo."

    show celular mateo:
        zoom 0.5
        xalign 0.5
        yalign 0.5

    yo "¿Aló?"
    mateo "Hola, soy yo. Calmate, ¿ya? Esto le pasa a muchísima gente y casi siempre se arregla. A ver, cuéntame cómo fue."
    yo "No sé. Hoy en la tarde entré normal. Y ahora mi clave no sirve y mi cuenta está mandando links a medio colegio."
    mateo "Ya... Una pregunta, pero sin regañarte: esa clave, ¿la usas en otras cosas? No me la digas, solo dime sí o no."
    narrador "Me quedo en silencio un segundo de más."
    yo "...En casi todo. Es que si pongo una distinta en cada cuenta me olvido de todas."
    mateo "Me lo imaginaba. Y no te lo digo para molestarte, casi todos hacemos eso."
    mateo "El problema es cómo funciona el robo de cuentas. A veces una página cualquiera, un juego, un sorteo, un foro, guarda mal las claves y se filtran. Quien las consigue las prueba una por una en las redes, en el correo, en todo."
    yo "O sea que no tuvieron que adivinar nada."
    mateo "Exacto. Les bastó con que fuera la misma clave en todas partes."

    # Si no avisó al inicio, Mateo se lo recuerda
    if not avisaste_pronto:
        mateo "Otra cosa: ¿ya avisaste al grupo del curso de que no abran ese link?"

        menu:
            "Ahora mismo lo escribo":
                narrador "Cuelgo un momento y escribo en el chat del curso, lo más claro que puedo."
                chat "Yo: No abran el link que salió de mi cuenta. Me la hackearon. No pongan su clave en ningún lado."
                chat "Sofía: ay no"
                chat "Sofía: [nombre_jugador] ya lo abrí. Puse mi usuario y mi clave para ver las fotos"
                $ sofia_afectada = True
                yo "Sofi... cambia tu clave ahora mismo. Y si usas esa en otras cuentas, también."
                chat "Sofía: chuta, ya voy. perdón perdón perdón"
                narrador "Llegué tarde por muy poco. Por lo menos ahora los demás están avisados."

            "Mañana, cuando los vea en el colegio":
                $ puntos -= 1
                $ sofia_afectada = True
                yo "Mejor mañana nos vemos y les explico bien."
                mateo "Mmm, esperemos que nadie se quede en el camino. Aunque contigo nunca se sabe..."
                narrador "Mateo no dice nada más. Y yo tampoco tengo muy claro por qué dije eso."

    mateo "Bueno, vamos a lo importante. ¿Qué cuenta aseguramos primero?"

    menu:
        "La red social, que es la que están usando ahora":
            jump h2_social_primero

        "El correo, por si también entraron ahí":
            $ puntos += 2
            yo "Si tienen mi clave de siempre, también pueden entrar a mi correo, ¿no?"
            mateo "Eso mismo estaba pensando. El correo es muy importante: ahí llegan los códigos para recuperar todo lo demás."
            jump h2_asegurar_correo

        "Mañana lo arreglo, ya es muy tarde":
            jump h2_dejarlo


# ---------------------------------------------------------------------
#  Camino A: recupera primero la red social (y aprende por qué no)
# ---------------------------------------------------------------------
label h2_social_primero:

    yo "Voy a recuperar la cuenta primero. Es la que están usando."
    mateo "Dale, pero fíjate en cada cosa que te pida."

    narrador "Toco «¿Olvidaste tu contraseña?». La app dice que enviará un código a mi correo."
    narrador "Abro el correo. Sigue abierto, y ahí está el código."
    narrador "Lo pongo, elijo una clave nueva y... entro. Por fin respiro."
    narrador "Dos minutos después, la pantalla se cierra sola. En el correo aparece un mensaje nuevo: «Se cambió la contraseña de tu cuenta»."

    yo "¿Otra vez? Si acabo de cambiarla yo. ¿Quién...?"
    mateo "Quien esté dentro de tu correo. Ve los códigos y los usa antes que tú. Por eso el correo va primero: si no lo cierras, todo lo que recuperes te lo quitan de nuevo."
    yo "O sea que perdí diez minutos."
    mateo "Perdiste diez minutos y ganaste la regla de oro: primero el correo. Vamos."

    jump h2_asegurar_correo


# ---------------------------------------------------------------------
#  Camino C: lo deja para el día siguiente
# ---------------------------------------------------------------------
label h2_dejarlo:

    yo "Mateo, de verdad, mañana. Ya no puedo más."
    mateo "Te entiendo... pero mientras esperas, quien entró sigue adentro, y puede seguir escribiendo a tus contactos. Piénsalo un segundo."
    yo "Mañana. De verdad."
    mateo "Está bien. Avísame apenas despiertes."

    $ puntos -= 2
    $ sofia_afectada = True

    hide celular mateo

    scene black with fade
    narrador "Esa noche casi no duermo. Sé que la cuenta sigue en manos de otra persona, y no puedo hacer nada con eso en la cabeza."
    narrador "A las seis de la mañana, antes de que suene la alarma, intento entrar al correo. La clave ya no sirve."

    jump h2_manana


# ---------------------------------------------------------------------
#  Asegurar el correo (camino A y B)
# ---------------------------------------------------------------------
label h2_asegurar_correo:

    scene bg cuarto oscuro with dissolve
    show celular mateo:
        zoom 0.5
        xalign 0.5
        yalign 0.5

    mateo "Entra a tu correo. Vamos a sacar a cualquiera que esté dentro y a cambiarle la clave."
    narrador "Abro la configuración de seguridad. Hay una lista de dispositivos con la sesión abierta. Uno de ellos no lo reconozco: otro aparato, desde otro lugar."
    narrador "Toco «Cerrar sesión en todos los dispositivos»."
    $ correo_asegurado = True
    mateo "Perfecto. Ahora la clave nueva. Aquí no me vayas por lo fácil: ¿cuál vas a poner?"

    menu:
        "La de siempre, pero cambiando un número":
            yo "Pongo la de siempre y le cambio el 1 por un 2. Así me acuerdo."
            mateo "Ay, no. Esa es la primera variación que prueba cualquiera que tenga la clave vieja. Cambiar un número no es cambiar la clave."
            yo "Ok, ok... ¿Entonces qué hago?"
            mateo "Una frase larga, de esas que solo tú entiendes. Algo así como «mi tía baila cumbia en la ducha». Esa no la uses, ¿eh? Piensa en la tuya."
            narrador "Termino armando una frase larga con ayuda de Mateo. Funciona, pero fue gracias a que él me frenó a tiempo."
            # Sin puntos extra: la corrigió con ayuda

        "Una combinación rara de letras, números y símbolos":
            $ puntos += 1
            yo "Algo como una mezcla rara: letras, números, símbolos."
            mateo "Es bastante mejor que lo de antes. El problema es que vas a olvidarla en dos días y terminarás anotándola en un papel pegado al monitor."
            mateo "Mejor una frase larga: es más fácil de recordar y mucho más difícil de adivinar. Larga le gana a rara."
            yo "O sea que si es larga, no importa que sea simple."
            mateo "Importa que no sea una frase famosa ni algo que esté en tus redes. Pero sí, largo y personal es la combinación."
            narrador "Cambio la mía por una frase larga. Me cuesta un poco acostumbrarme a escribirla, pero me la sé."

        "Una frase larga y personal, de esas que solo yo entiendo":
            $ puntos += 2
            $ clave_fuerte = True
            yo "Una frase larga. Algo que solo yo sepa y que no esté en mis redes."
            mateo "Eso. Cuatro o cinco palabras sueltas con algo tuyo, sin fechas de cumpleaños ni nombres de mascotas que ya publicaste."
            mateo "Si quieres, un ejemplo de broma: «mi tía baila cumbia en la ducha». Esa no la uses, ¿eh?"
            yo "Jaja. No, no la uso."
            narrador "Escribo la mía. Es larga, un poco rara, y es mía."

    mateo "Listo. Ahora duerme algo. Mañana recuperamos la red con calma."

    scene black with fade
    hide celular mateo
    narrador "Son casi las doce cuando dejo el celular boca abajo. Me cuesta dormirme, pero la cabeza ya no da tantas vueltas."

    jump h2_manana


# =====================================================================
#  ACTO 2 - EL LUNES
# =====================================================================
label h2_manana:

    scene bg entrada with fade
    # play music "audio/colegio_manana.ogg" fadein 1.0

    narrador "Lunes, 7:10 de la mañana. La entrada del colegio está llena de estudiantes y de gente mirando el celular."

    if avisaste_pronto:
        show valeria neutro at personaje_normal
        show valeria hablando at personaje_normal
        valeria "¡[nombre_jugador]! Menos mal que avisaste anoche. En mi salón nadie abrió ese link."
        hide valeria neutro
        hide valeria hablando
        show sofia nerviosa at personaje_normal
        sofia "Yo casi lo abro, de verdad. Tenía el dedo encima. Pero vi tu aviso y me frené."
        show sofia neutro at personaje_normal
        yo "Uf. Menos mal."
        show sofia sorprendida at personaje_normal
        sofia "Aunque ahora me da miedo. ¿Y si me pasa a mí? Yo uso la misma clave en todo."
        hide sofia neutro
        hide sofia sorprendida
        show mateo hablando at personaje_normal
        mateo "Pues justo de eso vamos a hablar."

    else:
        show sofia nerviosa at personaje_normal
        sofia "[nombre_jugador]... tengo que decirte algo."
        hide sofia nerviosa
        show sofia afectada at personaje_normal
        sofia "Anoche abrí el link. Puse mi usuario y mi clave para ver las fotos. Hoy ya no puedo entrar a mi cuenta."
        yo "Ay, Sofi..."
        hide sofia afectada
        show sofia nerviosa at personaje_normal
        sofia "No, fue mi culpa. Ni me fijé en la dirección. Era igualita a la página de verdad."
        hide sofia nerviosa
        show valeria hablando at personaje_normal
        valeria "Eso le pasa a casi todo el mundo. Lo importante es que cambies la clave ya, y la de cualquier otra cuenta donde la hayas usado."
        hide valeria hablando
        show sofia nerviosa at personaje_normal
        sofia "O sea... todas."
        hide sofia nerviosa
        show mateo hablando at personaje_normal
        mateo "Sí. Todas. Pero se arregla, ya verás."
        hide mateo hablando

    hide mateo hablando
    show valeria nerviosa at personaje_normal
    valeria "Ah, y [nombre_jugador]: Miss Carolina me preguntó por el mensaje raro que llegó al grupo. Le conté lo que pasó. Quiere hablar contigo en el salón, no es para regañarte."
    yo "Está bien. Voy."
    hide valeria nerviosa

    jump h2_carolina


# =====================================================================
#  CON MISS CAROLINA
# =====================================================================
label h2_carolina:

    scene bg salon with dissolve
    show carolina hablando at personaje_normal
    carolina "Pasa, [nombre_jugador]. Valeria me contó lo del link. Antes de nada: no hiciste nada de lo que debas avergonzarte. A cualquiera le puede pasar."
    show carolina neutro at personaje_normal
    hide carolina hablando 
    show carolina neutro at personaje_normal
    yo "Gracias, Miss. Es que siento que debí darme cuenta antes."
    hide carolina neutro

    if correo_asegurado:
        show carolina pregunta at personaje_normal
        carolina "¿Ya recuperaste tu cuenta?"
        show carolina neutro at personaje_normal
        yo "Anoche cambié primero el correo, con ayuda de Mateo. Falta recuperar la red."
        show carolina hablando at personaje_normal
        carolina "Muy bien: ese orden es el que se recomienda. Primero el correo, porque de ahí salen los códigos de todo lo demás."
        carolina "Vamos a recuperarla ahora, con calma."
        show carolina neutro at personaje_normal
        narrador "Pido el código de recuperación. Llega a mi correo, que ya está cerrado a cualquier otra persona. Escribo una clave nueva, larga y distinta a la del correo."
        narrador "Entro. Está todo en su lugar, y hay una lista de mensajes enviados a mi nombre que yo no escribí. Los borro uno por uno."

    else:
        show carolina hablando at personaje_normal
        carolina "Cuéntame bien qué pasó con el correo."
        show carolina neutro at personaje_normal
        yo "Esta mañana la clave ya no sirvió. Creo que también lo tienen."
        show carolina hablando at personaje_normal
        carolina "Entonces vamos por partes. Hay un formulario de recuperación: te piden datos que solo la persona dueña de la cuenta sabría, como cuándo la creaste, o con quién hablabas con frecuencia."
        carolina "Puede tardar desde unas horas hasta varios días. Pero se puede, y lo hacemos juntos, ahora."
        show carolina neutro at personaje_normal
        narrador "Llenamos el formulario con calma, campo por campo. Miss Carolina me ayuda a recordar cosas que ni sabía que sabía."
        narrador "Al final aparece un mensaje: «Revisaremos tu solicitud». Ahora toca esperar."
        yo "¿Y si no me creen?"
        show carolina hablando at personaje_normal
        carolina "Te lo pedirán de nuevo, y lo intentamos de nuevo. Lo importante es que ya empezamos, y que no tienes que hacerlo sin ayuda."
        hide carolina neutro
        hide carolina hablando

    show carolina hablando at personaje_normal
    carolina "Ahora, dos cosas que cambian muchísimo el riesgo. La primera: una clave distinta para cada cuenta importante. Empezando por el correo, que es la llave de las demás."
    show carolina neutro at personaje_normal
    yo "Pero ¿cómo me acuerdo de tantas?"
    show carolina hablando at personaje_normal
    carolina "No tienes que acordarte de todas. Existen los administradores de contraseñas, que son como una caja fuerte que se abre con una sola frase larga. Y la segunda cosa es la verificación en dos pasos: aunque alguien tenga tu clave, le falta un segundo permiso."
    carolina "Una regla más, y esta es de oro: la clave no se comparte con nadie. Ni con tu mejor amigo ni con tu pareja. Hoy confías, y mañana no se sabe."
    hide carolina neutro
    hide carolina hablando

    show carolina pregunta at personaje_normal
    menu:
        
        carolina "¿Activamos la verificación en dos pasos? Hay varias formas."

        "Con una app de autenticación":
            $ puntos += 2
            $ dos_pasos = True
            show carolina hablando at personaje_normal
            carolina "Es la opción más sólida: el código se genera en tu propio teléfono y cambia cada pocos segundos."
            carolina "Guarda los códigos de respaldo en un lugar seguro, que no sea el mismo teléfono. Si lo pierdes, te salvan."

        "Con mensaje de texto (SMS)":
            $ puntos += 1
            $ dos_pasos = True
            show carolina hablando at personaje_normal
            carolina "Es muchísimo mejor que nada. Aunque la app es más segura: en algunos ataques los mensajes de texto pueden desviarse."
            carolina "Puedes empezar por aquí y cambiarla por la app más adelante, cuando te acostumbres."

        "No la activo, me parece muy complicado":
            show carolina hablando at personaje_normal
            carolina "Te entiendo: son unos diez segundos más cada vez que entras. Pero es justo lo que habría frenado a quien entró anoche, aunque tuviera tu clave."
            carolina "No te voy a obligar. Piénsalo, ¿sí?"

    hide carolina hablando
    show carolina hablando at personaje_normal
    carolina "Y ahora la parte aburrida pero importante: ¿qué haces con tus otras cuentas, las que tienen la clave vieja?"
    show carolina pregunta at personaje_normal

    menu:
        "Las cambio hoy, empezando por las más importantes":
            $ puntos += 2
            $ claves_distintas = True
            yo "Hoy en la tarde. Primero las que tienen mis datos, después los juegos."
            show carolina hablando at personaje_normal
            carolina "Perfecto. Haz una lista y ve tachando. Y si puedes, usa ese administrador de contraseñas para no tener que memorizarlas."

        "Cambio solo la de esta cuenta y las demás ya veré":
            yo "Cambio esta y las demás, después."
            show carolina hablando at personaje_normal
            carolina "Lo entiendo, pero mientras esas sigan con la clave vieja, la puerta sigue abierta. Mínimo, el correo y las cuentas donde pusiste datos personales."
            carolina "Piénsalo esta semana, ¿sí?"

    jump h2_final
    hide carolina hablando
    hide carolina pregunta


# =====================================================================
#  ACTO 3 - EL FINAL
# =====================================================================
label h2_final:

    scene bg terraza with fade
    # play music "audio/final_calma.ogg" fadein 1.0

    narrador "Hora del recreo. Me siento en la terraza con Mateo, Sofía y Valeria. Por primera vez en veinticuatro horas, el celular no me da ansiedad."

    # Escoge el final según las decisiones
    if puntos >= 8:
        jump h2_final_bueno
    elif puntos >= 3:
        jump h2_final_regular
    else:
        jump h2_final_malo


label h2_final_bueno:
    scene black with fade
    centered "Final bueno"

    show sofia neutro at personaje_normal
    show sofia nerviosa at personaje_normal
    sofia "Mi cuenta ya volvió, y cambié todas mis claves. Mateo me ayudó a poner frases largas."
    hide sofia neutro
    hide sofia nerviosa
    show mateo hablando at personaje_normal
    mateo "Y ahora tiene verificación en dos pasos. Me lo prometió."
    hide mateo hablando
    show valeria nerviosa at personaje_normal
    valeria "Anoche pensé que ibas a perder la cuenta para siempre."
    show valeria neutro at personaje_normal
    yo "Yo también. Pero avisar a tiempo, asegurar el correo y pedir ayuda fue lo que marcó la diferencia."
    hide valeria nerviosa
    hide valeria neutro

    if sofia_afectada:
        narrador "Sofía tardó unos días en recuperar todo. No fue gratis: aprendimos juntos a costa de un susto. Pero lo aprendimos."

    narrador "FIN: Una sola clave abre muchas puertas. Una clave para cada puerta las cuida todas."
    jump h2_digi


label h2_final_regular:
    scene black with fade
    centered "Final regular"

    show sofia neutro at personaje_normal
    show sofia nerviosa at personaje_normal
    sofia "Mi cuenta ya volvió. Y ahora que lo pienso, tengo que cambiar muchas claves más."
    hide sofia neutro
    hide sofia nerviosa
    show mateo hablando at personaje_normal
    mateo "Te ayudo esta tarde. Ustedes también: lo que dejan sin cambiar es lo que usan para volver a entrar."
    hide mateo hablando
    if correo_asegurado:
        show valeria hablando at personaje_normal
        valeria "Algo es algo. Ya recuperaste la cuenta."
        show valeria neutro at personaje_normal
        yo "Sí... pero sé que me faltaron cosas. No quiero que me pase otra vez."
        hide valeria neutro
        hide valeria hablando
    else:
        show valeria hablando at personaje_normal
        valeria "Algo es algo. Ya empezaron a revisar lo de tu correo."
        show valeria neutro at personaje_normal
        yo "Sí... pero sé que me faltaron cosas. Y hasta que no respondan, sigo con el pendiente."
        hide valeria neutro
        hide valeria hablando
    
    narrador "FIN: Recuperé mi cuenta, pero quedaron puertas abiertas. Todavía puedo cerrarlas."
    jump h2_digi


label h2_final_malo:
    scene black with fade
    centered "Final malo"

    if correo_asegurado:
        show valeria nerviosa at personaje_normal
        valeria "Al menos recuperaste la cuenta. Pero sigues con la misma clave en todo lo demás, ¿no?"
        show valeria neutro at personaje_normal
        yo "Sí... y sin ningún segundo permiso. Si vuelve a pasar, estoy igual que antes."
        hide valeria nerviosa
        hide valeria neutro
        show sofia nerviosa at personaje_normal
        sofia "Varios del curso me preguntaron si lo que mandaste era verdad. Hasta hoy dudaban."
        hide sofia nerviosa
        show mateo hablando at personaje_normal
        mateo "Aún se puede arreglar. Pero hay que hacerlo ya, y con ayuda."
        hide mateo hablando
    else:
        show valeria hablando at personaje_normal
        valeria "Todavía no sabes cuándo vas a recuperar el correo, ¿verdad?"
        show valeria pregunta at personaje_normal
        yo "No. Dice que puede tardar días. Y mientras tanto, mi cuenta sigue mandando mensajes."
        hide valeria hablando
        hide valeria pregunta
        show sofia nerviosa at personaje_normal
        sofia "A mí me escribieron varios del curso preguntando si lo que mandaste era verdad..."
        hide sofia nerviosa
        show mateo hablando at personaje_normal
        mateo "Aún se puede arreglar. Pero hay que hacerlo ya, y con ayuda."
        hide mateo hablando

    narrador "FIN: Esperar tiene costo, y lo pagan también los que te rodean. Todavía estás a tiempo de empezar."
    jump h2_digi


# ---------------------------------------------------------------------
#  Cierre con Digi: resumen y opción de repetir
# ---------------------------------------------------------------------
label h2_digi:

    scene black with fade

    digi "¡Hola! Soy Digi. Antes de cerrar esta historia, te dejo tres cosas para llevarte."
    digi "Uno: una clave distinta para cada cuenta importante, empezando por el correo, que es la llave de las demás."
    digi "Dos: las frases largas le ganan a las claves raras. Y no se comparten con nadie."
    digi "Tres: activa la verificación en dos pasos. Es el seguro que te salva cuando la clave falla."
    digi "Y si te pasa algo así: avisa a tus contactos, asegura primero el correo y pide ayuda a un adulto de confianza."

    menu:
        "¿Qué quieres hacer ahora?"

        "Volver a jugar esta historia":
            jump historia2

        "Terminar":
            return

# =====================================================================
#  SAFECLIC - HISTORIA 6: "Antes de compartir"
#  Tema: información falsa, clickbait, deepfakes y verificación de fuentes
#  Archivo: game/historia6.rpy   (guardar en UTF-8)
#
#  Se juega desde menu_principal.rpy con "call historia6".
#  Personajes, fondos, transform y variables compartidas: comun.rpy
# =====================================================================

# --- Variables de esta historia ---
default compartiste_falso = False   # compartió el video antes de comprobarlo
default avisaste_grupo    = False   # avisó al curso con pruebas
default n_vchecks         = 0       # revisiones hechas al video
default v_visual          = False
default v_oficial         = False
default v_adulto          = False
default v_origen          = False


label historia6:

    # Reinicia el estado por si la historia se juega más de una vez
    $ puntos = 0
    $ compartiste_falso = False
    $ avisaste_grupo = False
    $ n_vchecks = 0
    $ v_visual = False
    $ v_oficial = False
    $ v_adulto = False
    $ v_origen = False

    if nombre_jugador == "":
        $ nombre_jugador = renpy.input("Antes de empezar, ¿cómo te llamas?", length=14).strip()
        if nombre_jugador == "":
            $ nombre_jugador = "Alex"

    scene black with fade
    centered "{size=+8}Historia 6{/size}\n{b}Antes de compartir{/b}"

    scene bg cuarto oscuro with fade
    # play music "audio/noche_tranquila.ogg" fadein 1.0

    narrador "Martes por la noche. Estoy a punto de dormirme cuando el chat del curso explota: cuarenta mensajes en dos minutos."
    show celular:
        zoom 0.5
        xalign 0.5
        yalign 0.5
    chat "Sofía: ¡¡¡MIREN ESTE VIDEO!!!"
    narrador "Lo abro. Es un video de unos veinte segundos: el rector, frente a la puerta del colegio, con cara muy seria."
    narrador "En el video, el rector dice: «Estimados estudiantes: por una alerta de seguridad, mañana se suspenden las clases. Descansen y no salgan de casa»."
    chat "Sofía: SIII NO HAY CLASES"
    chat "Valeria: ¿en serio? ¿quién lo mandó?"
    chat "Sofía: da igual, compártanlo a los otros grupos!!"

    menu:
        "El chat no para. ¿Qué hago?"

        "Compartirlo en otros grupos, ¡qué buena noticia!":
            $ puntos -= 2
            $ compartiste_falso = True
            narrador "Lo reenvío a tres grupos más. En diez minutos ya lo están reenviando personas que ni conozco."
            show celular mateo:
                zoom 0.5
                xalign 0.5
                yalign 0.5
            chat "Mateo: oigan, eso es raro. Espérense, déjenme mirarlo bien"
            hide celular mateo
            jump h6_video_decision

        "Esperar y comprobar antes de compartir":
            $ puntos += 1
            narrador "Tengo el dedo sobre el botón de reenviar, pero lo retiro. Si es verdad, no se va a ir a ningún lado. Primero lo compruebo."
            jump h6_video_check

        "No hacer nada, no es asunto mío":
            narrador "Silencio el chat y dejo el celular a un lado. Que cada quien haga lo que quiera."
            jump h6_video_decision
    hide celular

# ---------------------------------------------------------------------
#  Comprobación del video: el jugador elige qué revisar
# ---------------------------------------------------------------------
label h6_video_check:

    if n_vchecks >= 4:
        jump h6_video_decision

    show celular :
        zoom 0.5
        xalign 0.5
        yalign 0.5
    menu:
        "¿Qué compruebo?"

        "Mirar el video con atención: labios, voz, parpadeos, bordes de la cara" if not v_visual:
            $ v_visual = True
            $ n_vchecks += 1
            $ puntos += 1
            narrador "Lo veo tres veces, más despacio. La boca no siempre coincide con la voz y la cara se ve un poco «planchada» cuando mueve la cabeza."
            narrador "La voz suena seria, pero sin pausas ni respiración. Muy perfecta... demasiado perfecta."
            jump h6_video_check

        "Buscar el anuncio en las cuentas oficiales del colegio" if not v_oficial:
            $ v_oficial = True
            $ n_vchecks += 1
            $ puntos += 1
            narrador "Reviso la página y las cuentas oficiales del colegio. Ni una palabra. Si suspenden las clases, lo publican ahí."
            jump h6_video_check

        "Preguntarle a un adulto del colegio" if not v_adulto:
            $ v_adulto = True
            $ n_vchecks += 1
            $ puntos += 1
            narrador "Le escribo a Miss Carolina. Me responde en cinco minutos."
            carolina "No hay ningún aviso de suspensión. Gracias por preguntar antes de dar por cierto. Voy a avisar a dirección."
            jump h6_video_check

        "Buscar quién lo subió primero" if not v_origen:
            $ v_origen = True
            $ n_vchecks += 1
            $ puntos += 1
            narrador "El video pasó de grupo en grupo. Nadie sabe de dónde salió. La primera cuenta que lo subió no tiene nombre ni foto."
            jump h6_video_check

        "Ya vi suficiente" if n_vchecks >= 2:
            jump h6_video_decision
    hide celular

    jump h6_video_check


label h6_video_decision:

    show celular mateo :
        zoom 0.5
        xalign 0.5
        yalign 0.5
    chat "Mateo: confirmado: eso es un deepfake"
    chat "Mateo: un deepfake es un video o un audio hecho o alterado con IA para que parezca que alguien dijo algo que nunca dijo"
    chat "Mateo: hoy se puede copiar una voz con muy pocos segundos de audio. Por eso hay que mirar cada video con cuidado"
    hide celular mateo

    show celular :
        zoom 0.5
        xalign 0.5
        yalign 0.5
    menu:
        "¿Qué hago ahora?"

        "Avisar al grupo con pruebas, y borrar mi mensaje" if compartiste_falso:
            $ puntos += 2
            $ avisaste_grupo = True
            chat "Yo: borré mi mensaje. El video del rector es falso: está hecho con IA y el colegio no ha anunciado nada. Miss Carolina ya lo sabe"
            chat "Valeria: gracias por avisar"
            narrador "Siento vergüenza por haberlo compartido, pero corregir a tiempo vale más que quedarse callado."

        "Avisar al grupo con pruebas" if not compartiste_falso:
            $ puntos += 2
            $ avisaste_grupo = True
            chat "Yo: ojo, el video del rector es falso: está hecho con IA y el colegio no ha anunciado nada. Miss Carolina ya lo sabe"
            chat "Valeria: ¡uf! menos mal, casi no vengo mañana"
            narrador "Varios borran el mensaje. Sofía manda un emoji de calavera, avergonzada."

        "Borrar mi mensaje y no decir nada" if compartiste_falso:
            narrador "Borro mi mensaje y no digo nada. Pero ya lo vieron muchos, y el video sigue dando vueltas en otros grupos."

        "No decir nada, no es mi problema" if not compartiste_falso:
            narrador "Prefiero no meterme. Total, mañana alguien más lo aclarará."

        "Dejarlo así, ya es tarde para arreglarlo" if compartiste_falso:
            $ puntos -= 1
            narrador "Pienso que ya es tarde para arreglarlo. Me equivoco: nunca es tarde para avisar."
    hide celular

    jump h6_clickbait


# =====================================================================
#  CASO 2 - EL CLICKBAIT
# =====================================================================
label h6_clickbait:

    scene bg bar with fade

    narrador "Miércoles, recreo. Sofía llega con el celular en la mano, otra vez."
    show sofia nerviosa at personaje_normal
    sofia "Mira este titular: «¡EL TRUCO DE LOS GENIOS PARA SACAR 10 EN TODO SIN ESTUDIAR! Los profesores lo odian»."
    hide sofia nerviosa
    show valeria hablando at personaje_normal
    valeria "Eso suena demasiado bueno."
    hide valeria hablando
    show sofia nerviosa at personaje_normal
    sofia "Pero dice «los genios». Tiene que ser verdad."
    hide sofia nerviosa
    show sofia neutro at personaje_normal

    menu:
        "¿Qué hago con este titular?"

        "Abrir la nota y ver qué dice de verdad":
            $ puntos += 1
            hide sofia neutro
            narrador "Abro la nota. Son tres párrafos de relleno, un «truco» que resulta ser «dormir bien» y un montón de anuncios. Ninguna fuente, ningún autor."
            show mateo hablando at personaje_normal
            mateo "Eso es clickbait. Un titular exagerado para que hagas clic, y así ganan plata con los anuncios."
            hide mateo hablando
            show sofia nerviosa at personaje_normal
            sofia "O sea que no es un truco de genios."
            hide sofia nerviosa
            show sofia neutro at personaje_normal
            yo "Es un truco de... dormir. Y de estudiar, claro."
            hide sofia neutro

        "Compartirlo, qué gracioso":
            hide sofia neutro
            show mateo neutro at personaje_normal
            narrador "Lo comparto con unos stickers de risa."
            hide mateo neutro
            show mateo hablando at personaje_normal
            mateo "Jaja, vale, pero ojo: cuando es una broma queda entre risas. Hay otros titulares que sí engañan a la gente."
            hide mateo hablando

        "Creérselo y probar el «truco»":
            $ puntos -= 1
            hide sofia neutro
            show mateo neutro at personaje_normal
            narrador "Pruebo el truco toda la noche. Saco 6."
            hide mateo neutro
            show mateo hablando at personaje_normal
            mateo "Eso pasa cuando uno cree en los atajos mágicos."
            hide mateo hablando

    hide sofia neutro

# =====================================================================
#  CASO 3 - LA CADENA ALARMISTA
# =====================================================================
label h6_cadena:

    scene bg cuarto with dissolve

    show celular :
        zoom 0.5
        xalign 0.5
        yalign 0.5
    narrador "Jueves por la tarde. Mamá me reenvía un mensaje que le mandó una tía."
    chat "Mamá: Mi vida, mira esto. Compártelo con todos tus contactos."
    chat "Cadena: ¡¡¡ALERTA!!! Están llevándose estudiantes a la salida de los colegios en una camioneta blanca. Hay fotos. Compártelo con todos, por si le salva la vida a alguien."
    narrador "Trae una foto borrosa de una camioneta y de un grupo de personas."
    narrador "Siento un cosquilleo de miedo. Mi primer impulso es reenviarlo a todos, por si acaso."

    menu:
        "¿Qué hago con esto?"

        "Reenviarlo a todos mis contactos, por si acaso":
            $ puntos -= 2
            narrador "Lo reenvío a todos mis contactos. Algunos me responden asustados."
            narrador "Más tarde, Mateo me escribe."
            chat "Mateo: oye, ese mensaje es falso. La foto es de otro país y de hace años"
            narrador "Se me cae el alma. Acabo de asustar a mucha gente por nada."
            jump h6_cadena_cierre

        "Mirar de dónde viene: quién lo escribió, qué fecha tiene y si lo confirma una fuente oficial":
            $ puntos += 2
            narrador "No tiene autor ni fecha. Busco la foto en internet con una búsqueda inversa: es de otro país y tiene años. Y no hay ninguna alerta de la Policía ni de los medios."
            narrador "Además, el texto está lleno de mayúsculas y signos de exclamación, y pide compartir «por si acaso». Todo suena a rumor."
            yo "Mamá, mira. Esto es falso."
            chat "Mamá: ay, casi lo reenvío a todo mi grupo. Gracias por revisar"
            jump h6_cadena_cierre

        "Decirle a mamá que seguro es mentira, sin revisar":
            chat "Yo: mamá, seguro es mentira"
            chat "Mamá: ¿y cómo sabes? ¿Y si es cierto?"
            narrador "No me cree. Tiene razón: sin pruebas, mi «seguro» no vale nada."
            narrador "Hago lo que debí hacer desde el principio: busco la foto, miro la fecha, busco una fuente oficial."
            narrador "La foto es de otro país y tiene años. No hay ninguna alerta de la Policía ni de los medios."
            chat "Yo: mamá, ya lo revisé. Es falso"
            chat "Mamá: ay, gracias por demostrármelo"
            jump h6_cadena_cierre
    hide celular


label h6_cadena_cierre:

    yo "Lo que cuesta es que da miedo y uno quiere compartir «por si acaso»."
    narrador "Un rumor falso también hace daño: asusta a la gente y distrae de las alertas reales."

    jump h6_final


# =====================================================================
#  EL FINAL
# =====================================================================
label h6_final:

    scene bg terraza with fade
    # play music "audio/final_calma.ogg" fadein 1.0

    narrador "Viernes, recreo. La terraza otra vez, con Sofía, Valeria y Mateo."

    if avisaste_grupo:
        narrador "Aquella noche, casi todo el curso dejó de reenviar el video. Al día siguiente hubo clases con normalidad, y el rector aclaró en el patio que ese video era falso."
    else:
        narrador "El video del rector siguió dando vueltas toda la noche. Al día siguiente, varios compañeros no vinieron al colegio, y el rector tuvo que aclarar que ese video era falso."

    if puntos >= 8:
        jump h6_final_bueno
    elif puntos >= 3:
        jump h6_final_regular
    else:
        jump h6_final_malo


label h6_final_bueno:
    scene black with fade
    centered "{size=+8}Historia 6{/size}\n{b}Final bueno{/b}"

    show valeria hablando at personaje_normal
    valeria "Ahora, antes de reenviar algo, nos preguntamos: ¿quién lo dice? ¿Desde cuándo? ¿Alguien más lo confirma?"
    hide valeria hablando
    show sofia nerviosa at personaje_normal
    sofia "Yo creo que voy a hacerme un letrero con eso."
    hide sofia nerviosa
    show mateo hablando at personaje_normal
    mateo "Un video también se puede falsear. Ver no siempre es creer."
    hide mateo hablando
    show mateo neutro at personaje_normal
    yo "Parar un momento antes de compartir no cuesta nada, y evita muchos problemas."
    hide mateo neutro

    narrador "FIN: En internet, parar un segundo antes de compartir es el mejor filtro."
    jump h6_digi


label h6_final_regular:
    scene black with fade
    centered "{size=+8}Historia 6{/size}\n{b}Final regular{/b}"

    show valeria hablando at personaje_normal
    valeria "A veces se nos escapa uno, y no pasa nada. Lo importante es corregir."
    hide valeria hablando
    show mateo hablando at personaje_normal
    mateo "Y revisar mejor la próxima vez."
    hide mateo hablando
    show mateo neutro at personaje_normal
    yo "Sí. Y aprender a dudar un poco más de lo que da mucho susto o mucha emoción."
    hide mateo neutro

    narrador "FIN: Algunas cosas se nos pasaron, pero ya sabes qué revisar la próxima vez."
    jump h6_digi


label h6_final_malo:
    scene black with fade
    centered "{size=+8}Historia 6{/size}\n{b}Final malo{/b}"

    show valeria hablando at personaje_normal
    valeria "Varios cayeron con el video y con la cadena. Y eso tuvo consecuencias."
    hide valeria hablando
    show mateo hablando at personaje_normal
    mateo "Todavía estás a tiempo de cambiarlo: parar, revisar, preguntar, y solo después compartir."
    hide mateo hablando
    show mateo neutro at personaje_normal
    yo "Lo sé. Me dejé llevar por la emoción y por el miedo."
    hide mateo neutro

    narrador "FIN: Compartir sin comprobar ayuda a que la mentira viaje más rápido que la verdad. Pero aprender a parar es posible."
    jump h6_digi


# ---------------------------------------------------------------------
#  Cierre con Digi: resumen y opción de repetir
# ---------------------------------------------------------------------
label h6_digi:

    scene black with fade

    digi "¡Hola! Soy Digi. Para cerrar toda la serie, te dejo cinco cosas para llevarte."
    digi "Uno: detente antes de compartir. Si algo te da mucho miedo, rabia o emoción, justo ahí hay que parar."
    digi "Dos: mira quién lo dice y desde cuándo. Si no tiene autor, ni fecha, ni fuente, desconfía."
    digi "Tres: busca en otros lugares. Si algo es verdad e importante, lo confirman las cuentas oficiales y los medios, no solo un mensaje reenviado."
    digi "Cuatro: los videos, las fotos y los audios también se pueden falsear con IA. Fíjate en detalles raros y confirma por otra vía."
    digi "Cinco: un titular exagerado quiere tu clic, no informarte. Y si ya compartiste algo falso, borra, avisa con pruebas y listo: corregir también es de valientes."

    menu:
        "¿Qué quieres hacer ahora?"

        "Volver a jugar esta historia":
            jump historia6

        "Terminar":
            return

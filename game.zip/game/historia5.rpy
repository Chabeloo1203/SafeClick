# =====================================================================
#  SAFECLIC - HISTORIA 5: "Demasiado bueno para ser cierto"
#  Tema: estafas digitales y phishing
#  Archivo: game/historia5.rpy   (guardar en UTF-8)
#
#  Se juega desde menu_principal.rpy con "call historia5".
#  Personajes, fondos, transform y variables compartidas: comun.rpy
# =====================================================================

# --- Personajes propios de esta historia ---
define mama   = Character("Mamá",        color="#d94a8c")
define abuelo = Character("Abuelo Paco", color="#b07a3c")

# --- Variables de esta historia ---
default sofia_cayo      = False
default perdiste_dinero = False
default abuelo_cayo     = False


label historia5:

    # Reinicia el estado por si la historia se juega más de una vez
    $ puntos = 0
    $ sofia_cayo = False
    $ perdiste_dinero = False
    $ abuelo_cayo = False

    if nombre_jugador == "":
        $ nombre_jugador = renpy.input("Antes de empezar, ¿cómo te llamas?", length=14).strip()
        if nombre_jugador == "":
            $ nombre_jugador = "Alex"

    scene black with fade
    centered "{size=+8}Historia 5{/size}\n{b}Demasiado bueno para ser cierto{/b}"

    scene bg bar with fade
    # play music "audio/colegio_recreo.ogg" fadein 1.0

    narrador "Es lunes, durante el recreo. Sofía llega corriendo a la cafetería con el celular en alto, como si fuera un trofeo."
    show sofia nerviosa at personaje_normal
    sofia "¡NO LO VAS A CREER! ¡Gané entradas VIP para el concierto! ¡Dos!"
    hide sofia nerviosa
    show mateo sorprendido at personaje_normal
    mateo "¿Ganaste... qué? Si ni participaste en nada."
    hide mateo sorprendido 
    show sofia nerviosa at personaje_normal
    sofia "Me llegó un mensaje. Mira."
    hide sofia nerviosa

    chat "Mensaje: ¡FELICIDADES! Eres la persona ganadora de 2 entradas VIP. Reclámalas en las próximas 2 horas aquí: concierto-vip-gratis.xyz. Ingresa tu usuario y tu clave para verificar tu identidad."

    show sofia nerviosa at personaje_normal
    sofia "Solo tengo que poner mi usuario y mi clave. ¡Y me quedan dos horas! Lo hago ahora mismo."
    hide sofia nerviosa
    show sofia neutro at personaje_normal

    menu:
        "Sofía ya tiene el dedo sobre el link. ¿Qué hago?"

        "Decirle que lo abra, a ver si es verdad":
            $ puntos -= 2
            $ sofia_cayo = True
            show sofia neutro at personaje_normal
            yo "Ábrelo, a ver qué pasa."
            narrador "Sofía escribe su usuario y su clave. La página muestra un cartel: «Error, inténtalo más tarde»."
            narrador "Diez minutos después, su cuenta le pide la contraseña otra vez. Y luego, ya no la deja entrar."
            hide sofia neutro
            show sofia nerviosa at personaje_normal
            sofia "Mi cuenta... no me deja entrar. ¿Qué pasó?"
            hide sofia nerviosa
            show mateo hablando at personaje_normal
            mateo "Eso se llama phishing. Es cuando un mensaje falso se hace pasar por algo de confianza para que entregues tus datos."
            hide mateo hablando
            show sofia nerviosa at personaje_normal
            sofia "Ay, no..."
            hide sofia nerviosa
            show mateo sorprendido at personaje_normal
            mateo "Rápido: cambia la clave desde el correo, cierra todas las sesiones y avisa a tus contactos. No pierdas tiempo."
            hide mateo sorprendido
            narrador "Sofía se pone manos a la obra, con las mejillas rojas. Yo me siento mal: pude haberla frenado."

        "Pedirle que espere y revisar el mensaje y el link juntos":
            $ puntos += 2
            show sofia neutro at personaje_normal
            yo "Espera, Sofi. Déjame ver eso antes de que pongas nada."
            narrador "Leemos el mensaje con calma, los tres."
            hide sofia neutro
            show mateo hablando at personaje_normal
            mateo "A ver: no participaste en ningún sorteo. El link termina en «.xyz» y no es de ninguna página oficial del concierto. Te meten prisa con las dos horas. Y te piden tu clave."
            mateo "Ningún sorteo de verdad te pide tu clave. Esto es phishing: un mensaje falso que se disfraza para pescarte los datos."
            hide mateo hablando
            show sofia nerviosa at personaje_normal
            sofia "Qué ilusa soy, casi lo hago."
            hide sofia nerviosa
            show sofia afectada at personaje_normal
            yo "No eres ilusa. Están hechos para parecer reales y para que no pienses."
            hide sofia afectada
            show sofia nerviosa at personaje_normal
            sofia "Gracias... en serio. Habría perdido mi cuenta."
            hide sofia nerviosa
            show sofia neutro at personaje_normal
            narrador "Sofía bloquea el número y reporta el mensaje."
            hide sofia neutro

        "Dejarla, es su problema":
            $ puntos -= 1
            $ sofia_cayo = True
            hide sofia neutro
            narrador "Me encojo de hombros. Sofía sale corriendo con el celular en la mano."
            show sofia afectada at personaje_normal
            narrador "Más tarde, la encuentro sentada, con los ojos rojos. Perdió el acceso a su cuenta."
            hide sofia afectada
            show mateo hablando at personaje_normal
            mateo "Podías haberla frenado, ¿sabes?"
            hide mateo hablando
            show mateo neutro at personaje_normal
            narrador "Lo sé. Y me siento fatal."
            hide mateo neutro
    hide sofia neutro


# =====================================================================
#  CASO 2 - EL FALSO FAMILIAR
# =====================================================================
label h5_caso_mama:

    scene bg cuarto oscuro with dissolve

    show celular :
        zoom 0.5
        xalign 0.5
        yalign 0.5
    narrador "Esa noche, mientras repaso para la prueba de Historia, llega un mensaje de un número que no tengo guardado."
    
    chat "Número desconocido: Hola mi vida, se me dañó el celular y este es mi número nuevo. Guárdalo, ¿sí?"
    chat "Número desconocido: Necesito que me ayudes con algo urgente, te explico luego."
    yo "¿Mamá? Qué raro."
    chat "Número desconocido: Tengo que pagar algo hoy mismo y mi cuenta me da error. ¿Me haces una transferencia de 80 dólares? Mañana te los devuelvo."

    menu:
        "Es mi mamá... ¿o no? ¿Qué hago?"

        "Hacer la transferencia, es mi mamá y es urgente":
            $ puntos -= 3
            $ perdiste_dinero = True
            narrador "Hago la transferencia con mis ahorros. Quiero ayudar."
            chat "Número desconocido: Gracias mi vida. Una cosa más: ¿me haces otra de 120?"
            narrador "Veinte minutos después, me llega un mensaje de mamá desde su número de siempre. Me pregunta si ya estudié."
            narrador "Se me cae el alma al piso."
            jump h5_mama_llama

        "Preguntarle algo que solo mamá sabría":
            $ puntos += 2
            chat "Yo: ¿cómo se llama mi profe favorita de Lengua?"
            chat "Número desconocido: Mi vida, no hay tiempo para eso. Mejor haz la transferencia ya."
            narrador "Cuando alguien esquiva la pregunta más simple y solo insiste con la plata, algo no va bien."
            yo "Voy a llamarla igual."
            jump h5_mama_llama

        "Llamar a mamá a su número de siempre":
            $ puntos += 3
            narrador "No contesto el mensaje. Prefiero llamarla directo, al número que siempre ha tenido."
            jump h5_mama_llama
    hide celular


label h5_mama_llama:

    show celular mama :
        zoom 0.5
        xalign 0.5
        yalign 0.5
    mama "¿Aló? Hola, mi vida. ¿Pasó algo? ¿Ya estás estudiando?"
    yo "Mamá, ¿cambiaste de número?"
    mama "¿Cómo así? No, mi celular está aquí conmigo. ¿Por qué?"

    if perdiste_dinero:
        
        yo "Me escribieron de un número que decía ser tú. Me pidieron una transferencia... y la hice."
        mama "Ay, mi vida. Eso es una estafa muy común. No te regaño, mi vida. Vamos a llamar al banco ahora mismo."
        narrador "Llamamos al banco con el número oficial. Nos dicen que reporten el caso cuanto antes. No siempre se recupera el dinero, pero hay que intentarlo."
        narrador "Aprendí algo caro: que alguien diga ser tu familiar no basta. Hay que confirmar."
    else:
        yo "Alguien me escribió desde un número nuevo, diciendo que eras tú. Me pidió una transferencia."
        mama "Eso es una estafa, mi vida. Bloquea ese número y no hagas nada. Mándame la captura."
        mama "Qué bueno que me llamaste. Cuando alguien te pida plata, aunque parezca que soy yo, llámame siempre al número de siempre."
        narrador "Bloqueo el número. Todo salió bien."
    hide celular mama

    jump h5_caso_abuela


# =====================================================================
#  CASO 3 - LA LLAMADA A LA ABUELA
# =====================================================================
label h5_caso_abuela:

    scene bg cuarto with dissolve

    narrador "Sábado por la mañana. Suena el celular: es mi abuelo Paco."

    show celular abuelo :
        zoom 0.5
        xalign 0.5
        yalign 0.5
    abuelo "Mi cielo, ¿tienes un minutito?"
    yo "Claro, abuelo. ¿Qué pasó?"
    abuelo "Me acaban de llamar del banco, un joven muy educado. Dice que mi cuenta está bloqueada y que me va a llegar un código por mensaje para desbloquearla."
    abuelo "Ya me llegó el mensaje, mi cielo. Me dice que se lo diga, que es rapido. ¿Se lo doy?"

    narrador "Se me aprieta el estómago. Un código de verificación es como una llave: quien lo tiene, entra."

    menu:
        "Tengo que elegir rápido. ¿Qué le digo?"

        "Que se lo dé, que seguro es el banco":
            $ puntos -= 3
            $ abuela_cayo = True
            yo "Si es el banco, dáselo. Que te lo arreglen."
            abuelo "Ya, mi cielo."
            narrador "Escucho cómo lee el código en voz alta. Después, un silencio."
            abuelo "Mi cielo... me llegó un aviso de que salió plata de mi cuenta."
            narrador "Me quedo sin palabras. Llamo al banco con el número que está detrás de su tarjeta, y ellos bloquean todo y abren un reclamo."
            narrador "No siempre se recupera el dinero. Y yo pude haberlo evitado."

        "Que no le dé nada, que cuelgue y que llame ella al número que está detrás de su tarjeta":
            $ puntos += 3
            yo "Abuelo, no le des ese código a nadie. Cuelga y llama tú al número que está detrás de tu tarjeta."
            abuelo "¿Y si de verdad era el banco?"
            yo "Si era el banco, no pasa nada: llamas tú y te lo confirman. Pero ningún banco pide ese código por teléfono."
            narrador "Mi abuelo cuelga y llama. Diez minutos después, me vuelve a llamar."
            abuelo "Mi cielo, me dijeron que mi cuenta está bien y que ellos nunca piden códigos. Qué susto. Gracias por avisarme."

        "Pedirle el número de quien llamó para llamarlo yo":
            $ puntos -= 1
            yo "Abuelo, pásame el número de quien te llamó, yo lo llamo."
            narrador "Me detengo antes de que me lo diga. Hablar con ellos no tiene sentido: solo me pedirían lo mismo."
            yo "Mejor no, abuelo. Cuelga, y llama tú al número que está detrás de tu tarjeta."
            narrador "Mi abuelo hace lo que le digo. Era una estafa."

    abuelo "Tienes que explicarle esto a todos en la familia."
    yo "Eso voy a hacer."
    hide celular abuelo

    jump h5_reporte


# =====================================================================
#  EL CIERRE
# =====================================================================
label h5_reporte:

    scene bg terraza with fade
    # play music "audio/final_calma.ogg" fadein 1.0

    narrador "Terraza, durante el recreo. Por fin estamos los tres juntos otra vez."

    show mateo hablando at personaje_normal
    menu:
        mateo "Con tantos mensajes falsos dando vueltas, ¿qué hacemos con los que nos llegan?"

        "Reportarlos, bloquear los números y contarlo en casa":
            $ puntos += 2
            show mateo neutro at personaje_normal
            yo "Los reporto y bloqueo. Y también les cuento a mis papás y a mi abuela, para que no caigan."
            hide mateo neutro
            show mateo hablando at personaje_normal
            mateo "Eso. Reportar ayuda a que a otros no les llegue."
            hide mateo hablando

        "Solo borrarlos y seguir":
            show mateo neutro at personaje_normal
            yo "Los borro y ya."
            hide mateo neutro
            show mateo hablando at personaje_normal
            mateo "Está bien, pero si los reportas, ayudas a que no les lleguen a otras personas."
            hide mateo hablando

    if puntos >= 8:
        jump h5_final_bueno
    elif puntos >= 3:
        jump h5_final_regular
    else:
        jump h5_final_malo


label h5_final_bueno:
    
    scene black with fade
    centered "{size=+8}Historia 5{/size}\n{b}Final bueno{/b}"


    show sofia nerviosa at personaje_normal
    sofia "Yo ya puse un recordatorio en mi cabeza: si es demasiado bueno para ser cierto, probablemente no lo es."
    hide sofia nerviosa
    show mateo hablando at personaje_normal
    mateo "Y si alguien pide plata, códigos o claves, se confirma por otro lado."
    hide mateo hablando
    yo "Hoy casi pierdo muchas cosas. Pero revisé, pregunté y confirmé."

    narrador "FIN: Una estafa se apoya en la prisa y en la confianza. Parar un momento y confirmar por otro lado la desarma."
    jump h5_digi


label h5_final_regular:

    scene black with fade
    centered "{size=+8}Historia 5{/size}\n{b}Final regular{/b}"

    show sofia nerviosa at personaje_normal
    sofia "A mí me costó una cuenta, pero ya aprendí."
    hide sofia nerviosa
    show mateo hablando at personaje_normal
    mateo "Y a ti te salvó el banco, por poco."
    hide mateo hablando
    yo "Me tocó aprender un poco a las malas. La próxima, confirmo antes."

    narrador "FIN: Algunas estafas se frenaron a tiempo y otras no. Lo importante es que ya sabes cómo reconocerlas."
    jump h5_digi


label h5_final_malo:

    scene black with fade
    centered "{size=+8}Historia 5{/size}\n{b}Final malo{/b}"

    show sofia nerviosa at personaje_normal
    sofia "A mí me costó una cuenta..."
    hide sofia nerviosa
    show mateo hablando at personaje_normal
    mateo "Y a ti, plata. Y a tu abuelo, un susto enorme."
    hide mateo hablando 
    show mateo neutro at personaje_normal
    yo "Lo sé. Todo por actuar rápido, sin confirmar."
    hide mateo neutro
    show mateo hablando at personaje_normal
    mateo "Aún se puede arreglar: cambiar claves, avisar al banco, reportar. Y la próxima vez, parar un momento."
    hide mateo hablando

    narrador "FIN: Las estafas funcionan cuando te apuran. La pausa es tu mejor defensa."
    jump h5_digi


# ---------------------------------------------------------------------
#  Cierre con Digi: resumen y opción de repetir
# ---------------------------------------------------------------------
label h5_digi:

    scene black with fade

    digi "¡Hola! Soy Digi. Antes de cerrar esta historia, te dejo cuatro cosas para llevarte."
    digi "Uno: los premios que no pediste, las ofertas demasiado buenas y los mensajes que te meten prisa suelen ser trampa."
    digi "Dos: ningún sitio serio te pide tu clave, ni un código de verificación, por mensaje o por llamada. Esos códigos no se comparten con nadie."
    digi "Tres: si alguien dice ser tu familiar, tu banco o tu colegio y te pide plata o datos, cuelga y confirma por el número de siempre."
    digi "Cuatro: si ya caíste, no te quedes en silencio: cambia tus claves, avisa al banco y cuéntalo a un adulto. Cuanto antes, mejor."

    menu:
        "¿Qué quieres hacer ahora?"

        "Volver a jugar esta historia":
            jump historia5

        "Terminar":
            return

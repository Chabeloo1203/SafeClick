# =====================================================================
#  SAFECLIC - HISTORIA 1: "Lo que no se ve"
#  Tema: ciberacoso y difusión de contenido sin consentimiento
#  Archivo: game/historia1.rpy   (guardar en UTF-8)
#
#  Se juega desde menu_principal.rpy con "call historia1".
#  Personajes, fondos, transform y variables compartidas: comun.rpy
# =====================================================================

# --- Variables de esta historia ---
default puntos_dia1 = 0
default conto_secreto = False
default borro_audio = False
default reaccion = ""
default apoyo = False
default confeso = False
default mintio = False
default tiene_pruebas = False
default aviso_docente = False
default hablo_familia = False


label historia1:

    # Reinicia el estado por si la historia se juega más de una vez
    $ puntos = 0
    $ puntos_dia1 = 0
    $ conto_secreto = False
    $ borro_audio = False
    $ reaccion = ""
    $ apoyo = False
    $ confeso = False
    $ mintio = False
    $ tiene_pruebas = False
    $ aviso_docente = False
    $ hablo_familia = False

    scene black
    centered "Capítulo 1: Lo que no se ve"

    # El nombre se pregunta una sola vez en menu_principal.rpy
    $ nombre = nombre_jugador

    centered "Día 1"

    scene bg entrada with fade
    "Otro día en el colegio."

    # ---------- ESCENA 1: EL PATIO ----------
    scene bg patio with fade

    "Último recreo. El patio huele al pan del bar y al césped recién cortado."
    show valeria distraida at personaje_normal
    "Valeria lleva todo el día rara. Sonríe, pero con esa sonrisa que no le llega a los ojos."
    "Se sienta a mi lado en la banca y mira alrededor, como si alguien pudiera escucharnos."

    hide valeria distraida
    show valeria nerviosa at personaje_normal
    v "Tengo que contarte algo. Pero júrame que no se lo vas a decir a nadie."
    hide valeria nerviosa
    show valeria distraida at personaje_normal
    yo "Te lo juro. ¿Qué pasó?"
    show valeria avergonzada at personaje_normal
    v "Me gusta alguien de otro curso."
    "Lo dice tan bajito que casi no la escucho."
    hide valeria avergonzada
    show valeria nerviosa at personaje_normal
    v "Y grabé un audio practicando lo que le diría. Es horrible, me da vergüenza hasta escucharlo."
    v "Te lo mandé. Solo quiero que me digas si suena muy... ya sabes."
    hide valeria nerviosa
    show valeria neutro at personaje_normal

    "Mi celular vibra sobre la banca. La pantalla se enciende y muestra la vista previa del mensaje."
    "Un audio de Valeria. Casi dos minutos."
    "Al otro lado de la banca, Sofía levanta la vista de su celular por un segundo. Luego sigue en lo suyo."

    yo "No suena horrible. Suena como alguien nervioso, nada más."
    hide valeria neutro
    show valeria nerviosa at personaje_normal
    v "Bórralo después, ¿ya? Por favor. No quiero que exista en ningún lado."
    hide valeria nerviosa
    show valeria neutro  at personaje_normal
    yo "Tranquila. Lo borro."
    hide valeria neutro
    show valeria hablando at personaje_normal
    v "Voy al baño. Ya vengo."
    hide valeria hablando

    "Valeria se aleja. Casi enseguida, Mateo se deja caer en la banca con una funda de papitas."
    show mateo pregunta at personaje_normal
    m "¿Qué le pasa a Vale? Está rarísima hoy."
    

    # ---------- DECISION 1: el secreto ----------
    menu:
        "Mateo me mira, esperando una respuesta. Tengo que decir algo."

        "No es algo que te importe.":
            $ puntos += 1
            yo "Pregúntale a ella. Yo no te voy a contar nada."
            show mateo molesto at personaje_normal
            m "Uy, qué misteriosos. Bueno, bueno."
            "Mateo se encoge de hombros y sigue comiendo papitas. Parece que ahí termina todo."
            hide mateo molesto
            "Parece."

        "Le gusta alguien de otro curso. Pero no digas nada, ¿ya?":
            $ conto_secreto = True
            yo "Le gusta alguien de otro curso. Pero no digas nada, ¿ya? Es un secreto."
            show mateo sorprendido at personaje_normal
            m "Ah, mira tú. Tranquilo, no digo nada."
            hide mateo sorprendido
            show mateo sonrie at personaje_normal
            "Sonríe. Es una sonrisa pequeña, de esas que ya están pensando en otra cosa."
            "Algo en el estómago me dice que no debí abrir la boca."
            hide mateo sonrie
    hide mateo pregunta

    "Suena el timbre. Se acaba el recreo y volvemos al salón."
    scene bg salon with fade
    show valeria neutro at personaje_normal
    "Valeria regresa con la cara recién lavada y se sienta dos puestos más allá. Me hace un gesto con el pulgar: ¿todo bien?"
    hide valeria neutro

    if conto_secreto:
        show valeria sonrisa at personaje_normal
        "Le devuelvo el gesto. No le digo nada de lo que acabo de contarle a Mateo."
        hide valeria sonrisa
    else:
        show valeria sonrisa at personaje_normal
        "Le devuelvo el gesto. Una promesa cumplida, por ahora."
        hide valeria sonrisa

    # ---------- ESCENA 2: LA HABITACION, DE NOCHE ----------
    scene bg cuarto with fade

    show celular:
        zoom 0.5
        xalign 0.5
        yalign 0.5

    "Esa noche, en mi cuarto, el celular no para de vibrar. Es el chat del curso."
    "Mateo: alguien hizo la tarea de inglés??\nSofía: yo, después te paso una foto\nMateo: eres la mejor\nJavier: pásenmela a mí también jajaja"
    "Todo normal. Memes, stickers, tareas. Como cada noche."
    "Más arriba, entre mis conversaciones, está el chat con Valeria. Y en él, su audio, todavía sin borrar."
    "Me pidió que lo borrara. Pero hacerlo así, sin más, me da un poco de cosa."

    # ---------- DECISION 2: el audio ----------
    menu:
        "El audio sigue ahí, esperando."

        "Borrarlo ahora, como prometí.":
            $ puntos += 1
            $ borro_audio = True
            "Mantengo el dedo sobre el audio hasta que aparece la opción. Eliminar. Listo."
            "Un secreto menos que pueda salirse de donde no debe."

        "Dejarlo por hoy. Lo borro mañana.":
            "Lo dejo ahí. Mañana lo borro, seguro. Total, nadie más lo va a escuchar."
            "Eso pienso."

    scene bg cuarto oscuro with fade       
    "Dejo el celular sobre la mesita de noche y apago la luz."

    "Mañana será un día como cualquier otro."
    "Eso creía."
    hide celular

    jump historia1_dia2


# =====================================================
# DIA 2: EL PROBLEMA
# =====================================================
label historia1_dia2:

    # Guardamos los puntos del Día 1 por si el jugador reintenta el Día 2
    $ puntos_dia1 = puntos
    
    scene black
    centered "Día 2"

    # ---------- ESCENA 3: LA MAÑANA EN EL SALON ----------
    scene bg salon with fade

    "Llego al salón diez minutos antes. Valeria todavía no ha llegado."
    show sofia neutro at personaje_normal
    "Sofía se acerca con el celular en la mano."
    hide sofia neutro
    show sofia nerviosa at personaje_normal
    s "Oye, ¿me prestas el tuyo un segundo? Se me acabó la batería y necesito avisarle a mi mamá algo."
    hide sofia nerviosa
    show sofia neutro at personaje_normal
    yo "Claro, toma."
    "Se lo paso sin pensarlo mucho. Es Sofía; nos conocemos desde primaria."

    if borro_audio:
        "Teclea un momento, me lo devuelve y se va a su puesto. Nada raro."
    else:
        show sofia nerviosa at personaje_normal
        "Teclea un momento. Se detiene. Sus ojos se quedan quietos en la pantalla unos segundos de más."
        "Luego me lo devuelve y se va a su puesto sin decir nada."
        hide sofia nerviosa
    hide sofia neutro

    # ---------- ESCENA 4: EL CHAT ----------
    "Primera hora. Miss Carolina explica algo en la pizarra, pero nadie la escucha del todo."
    "Mi celular vibra en el bolsillo. Una vez. Diez veces. Treinta."
    show celular: 
        zoom 0.5
        xalign 0.5
        yalign 0.5
    "Lo saco bajo el pupitre. El chat del curso está lleno de mensajes."

    if not borro_audio:
        "Mateo: JAJAJAJA escuchen esto\n(audio reenviado)\nJavier: NO PUEDE SER jajajaja\nSofía: ya no puedo más"
        "Es la voz de Valeria. El audio que me mandó a mí. Alguien lo recortó donde más se nota que está nerviosa y le puso música cómica."
        "Solo yo tenía ese audio. Y yo no lo borré."
        if conto_secreto:
            "Y Mateo sabía de quién era cada palabra, porque se lo conté yo."
    elif conto_secreto:
        "Mateo: ojo ojo, en este salón alguien está enamorada y ensaya su declaración frente al espejo jajaja adivinen quién\nJavier: yo creo que sé quién es\nMateo: nunca digo nombres. Pero empieza con V"
        "Debajo, memes con la cara de Valeria y corazones encima."
        "Eso solo lo sabía yo. Y se lo conté a Mateo."
    else:
        "Mateo: ojo ojo, alguien en este salón anda enamorada jajaja, vi un cuaderno lleno de corazones\nJavier: ¿quién?? ¿quién??\nMateo: empieza con V"
        "Debajo, memes con la cara de Valeria y corazones encima."
        "No fui yo. Pero eso no me hace sentir mejor."

    show valeria avergonzada at personaje_normal
    "La puerta se abre. Valeria entra tarde, con la mochila a medio cerrar."
    "Mira su celular. Una vez. Luego levanta la cabeza y recorre el salón con la mirada. Algunos le sonríen de una forma que antes no veía."
    hide valeria avergonzada
    show valeria distraida at personaje_normal
    "Se sienta sin decir nada. Está pálida."

    # ---------- DECISION 3: reaccionar al chat ----------
    menu:
        "El chat sigue llenándose. Todos esperan a ver quién se suma al juego."

        "No reaccionar ni reenviar nada.":
            $ puntos += 1
            $ reaccion = "ninguna"
            "Guardo el celular. No es fácil: sé que mi silencio también se nota."

        "Poner una reacción de risa para no quedar mal.":
            $ reaccion = "risa"
            "Un solo toque. Una carita riendo. Nadie lo nota... eso creo."
            "Valeria levanta la vista de su celular y me mira. Se queda un segundo de más. Luego baja la mirada."

        "Escribir en el chat: ya basta, no es gracioso.":
            $ puntos += 1
            $ reaccion = "defensa"
            "Mateo: uy, llegó la defensora"
            "Algunos se ríen. Otros no contestan. Pero por un momento, el chat se frena."

    "Durante toda la hora, Valeria no mira su celular ni a nadie. En mi cabeza escribo y borro mensajes."

    # ---------- DECISION 4: escribirle a Valeria ----------
    menu:
        "Tengo su chat abierto. El cursor parpadea."

        "Escribirle: Estoy contigo. ¿Podemos hablar en el recreo?":
            $ puntos += 1
            $ apoyo = True
            "Envío el mensaje. Ella lo lee. No contesta. Pero lo lee."

        "Dejarlo pasar. Ya se le pasará.":
            "Cierro el chat. Seguro prefiere estar sola, me digo."

    # ---------- ESCENA 5: EL PATIO ----------
    hide valeria distraida

    scene bg patio with fade

    if apoyo:
        show valeria avergonzada at personaje_normal
        "En el recreo, Valeria viene hacia mí. Tiene los ojos rojos."
        hide valeria avergonzada
    else:
        show valeria distraida at personaje_normal
        "En el recreo la encuentro sola, en la banca de siempre, con la mirada clavada en el suelo."
        hide valeria distraida

    if reaccion == "risa":
        show valeria distraida at personaje_normal
        "Sé que vio mi reacción en el chat. Ninguno de los dos lo menciona."
        hide valeria distraida

    if conto_secreto:
        show valeria pregunta at personaje_normal
        v "Tengo que preguntarte algo y quiero que me digas la verdad. ¿Le contaste a Mateo lo que te dije?"
        hide valeria pregunta
        show valeria neutro at personaje_normal

        # ---------- DECISION 4B: la verdad ----------
        menu:
            "Me mira fijo. No hay forma de esquivar esta pregunta."

            "Sí. Se lo dije. Fue un error y lo siento muchísimo.":
                $ puntos += 1
                $ confeso = True
                show valeria nerviosa at personaje_normal
                v "Confiaba en ti."
                hide valeria nerviosa
                show valeria distraida at personaje_normal
                yo "Lo sé. No tengo excusa. Pero quiero ayudarte a arreglarlo."
                "Valeria se queda callada mucho rato. Duele, pero algo se afloja entre los dos."
                hide valeria distraida

            "No. Yo no fui.":
                $ mintio = True
                show valeria nerviosa at personaje_normal
                v "Ya... entonces nadie sabe cómo se enteraron."
                hide valeria nerviosa
                show valeria distraida at personaje_normal
                "Asiente, pero algo en su mirada se apaga. Quizás ya sabe la respuesta."
                hide valeria distraida
        hide valeria neutro    
    else:
        show valeria nerviosa at personaje_normal
        v "Gracias por no haberle dicho nada a nadie."
        hide valeria nerviosa
        show valeria neutro at personaje_normal
        "Lo dice como quien se agarra de lo único que le queda."
        hide valeria neutro
        if not borro_audio:
            show valeria nerviosa at personaje_normal
            v "Pero el audio... solo te lo mandé a ti. No entiendo cómo salió."
            hide valeria nerviosa
            show valeria neutro at personaje_normal
            "No sé qué responder. Todavía no sé cómo salió. Pero empiezo a sospecharlo."
            hide valeria neutro

    show valeria hablando at personaje_normal
    v "No quiero seguir hablando de esto. No ahora."
    hide valeria hablando
    show valeria distraida at personaje_normal
    "Se levanta y se va hacia el baño. Esta vez no la sigo."
    hide valeria distraida

    show sofia neutro at personaje_normal
    "Sofía se sienta donde estaba Valeria. Evita mirarme."

    if not borro_audio:
        show sofia nerviosa at personaje_normal
        s "Fui yo. Lo del audio. Cuando me prestaste el celular lo vi. Pensé que era una broma entre ustedes y se lo mandé a Mateo. No pensé que..."
        hide sofia nerviosa
        show sofia afectada at personaje_normal
        s "Perdón."
        hide sofia afectada
        show sofia neutro at personaje_normal
        "No es una disculpa que arregle algo, pero se nota que le pesa."
        "Y sé que ese audio no debía seguir ahí. Debí borrarlo cuando Valeria me lo pidió."
        hide sofia neutro
    hide sofia neutro

    show sofia nerviosa at personaje_normal
    s "Mira, en serio: no te metas. Si te metes, la agarran contigo. Esto se les pasa en dos días."
    hide sofia nerviosa

    show sofia neutro at personaje_normal
    # ---------- DECISION 5: las pruebas ----------
    menu:
        "Sofía espera que le diga que sí. Pero el chat sigue ahí, con todo lo que contiene."

        "Hacer capturas de pantalla de todo el chat y guardarlas.":
            $ puntos += 1
            $ tiene_pruebas = True
            "Hago capturas de los mensajes, de los memes, de los nombres y de las horas. Las guardo en una carpeta aparte."
            "Si algún día hace falta demostrar qué pasó, estarán ahí."

        "Salir del chat y borrar todo para no tener que verlo.":
            "Salgo del grupo y borro la conversación. El celular se siente más liviano."
            "Pero con eso también se va todo lo que podría demostrar lo que pasó."
    hide sofia neutro
    # ---------- ESCENA 6: MISS CAROLINA ----------
    scene bg salon with fade

    show carolina neutro at personaje_normal
    "Termina la jornada. Recojo mis cosas despacio, y Miss Carolina se acerca a mi puesto."
    hide carolina neutro
    show carolina pregunta at personaje_normal
    c "¿Tienes un minuto? Valeria no ha levantado la cabeza en todo el día, y el curso está más inquieto de lo normal. Sé que pasa algo, pero no sé qué."
    hide carolina pregunta
    show carolina hablando at personaje_normal
    c "Los adultos no vemos lo que pasa en los chats. Si sabes algo, necesito que me lo digas."

    # ---------- DECISION 6: avisar a la docente ----------
    menu:
        "Es la oportunidad. O la dejo pasar."

        "Contarle todo lo que sé.":
            $ puntos += 1
            $ aviso_docente = True
            if tiene_pruebas:
                yo "Miss, hay un chat del curso donde se están burlando de Valeria. Tengo capturas de todo."
                show carolina hablando at personaje_normal
                c "Gracias por contármelo, y por guardar las pruebas. Eso ayuda muchísimo. Hiciste lo correcto."
                hide carolina hablando
            else:
                yo "Miss, en el chat del curso se están burlando de Valeria. No guardé capturas, pero puedo decirle quiénes y qué dijeron."
                show carolina hablando at personaje_normal
                c "Gracias por decírmelo. Eso importa. Con lo que sepas, empezamos a revisar."
                hide carolina hablando
            "Es raro: tengo miedo, pero a la vez siento que me quité un peso de encima."
            

        "Decir: Nada, Miss. Todo bien.":
            yo "No, Miss. Nada. Todo bien."
            show carolina hablando at personaje_normal
            c "Está bien. Si cambias de opinión, mi puerta está abierta."
            hide carolina hablando
            "Se aleja. Me quedo con la sensación de haber cerrado una puerta que no sé si podré volver a abrir."
    hide carolina hablando

    # ---------- ESCENA 7: LA NOCHE ----------
    scene bg cuarto with fade

    show celular :
        zoom 0.5
        xalign 0.5
        yalign 0.5
    "Esa noche, el celular vuelve a vibrar. Pero esta vez no es el chat del curso."
    "Es Valeria."
    v "No sé qué hacer. No quiero ir mañana."

    # ---------- DECISION 7: la familia ----------
    menu:
        "Lo que le diga ahora puede cambiar el día de mañana."

        "Proponerle que hable con sus papás y ofrecerle acompañarla.":
            $ puntos += 1
            $ hablo_familia = True
            yo "No tienes por qué cargar esto sola. Si quieres, hablamos con tus papás juntos. Yo voy contigo."
            v "...¿Harías eso?"
            yo "Claro que sí."
            "Hay un silencio largo. Luego aparece su respuesta: Está bien."

        "Decirle que aguante, que mañana se les pasa.":
            yo "Ya verás que mañana se les pasa. Aguanta un día más."
            v "Ya..."
            "Lo dice, pero no suena convencida. Y yo tampoco."
    hide celular

    # ---------- RESULTADO ----------
    if puntos >= 5 and aviso_docente:
        jump historia1_final_bueno
    else:
        jump historia1_final_malo


# =====================================================
# FINALES
# =====================================================
label historia1_final_bueno:

    scene black
    centered "Final bueno: Alguien lo vio"

    "A la mañana siguiente, Valeria llega con sus papás. No viene sola."
    "Miss Carolina ya habló con la directora. Esa misma semana se aplica el protocolo de la institución: se revisa lo que pasó en el chat, se conversa con las familias de los involucrados y se pide cerrar el grupo."
    "Mateo tiene que escuchar a Valeria, con sus padres presentes. Su disculpa es incómoda, torpe y a medias. Pero llega."
    "Después, el curso tiene una charla sobre convivencia digital. No es un sermón: esta vez somos los estudiantes quienes ponemos las normas del chat."

    if mintio:
        "Con Valeria las cosas tardan un poco más. Todavía me cuesta mirarla a los ojos por haberle mentido ese día. Pero decide darme otra oportunidad, y yo decido no desperdiciarla."
    elif conto_secreto:
        "Valeria me perdonó lo del secreto. No fue rápido ni fácil, pero lo hizo, porque le dije la verdad."
    else:
        "Valeria me abraza en el patio. No dice nada. No hace falta."

    v "Pensé que nadie lo iba a ver."
    yo "Yo tampoco. Por eso no podía quedarme sin hacer nada."

    jump historia1_retroalimentacion


label historia1_final_malo:

    scene black
    centered "Final malo: Nadie lo vio a tiempo"

    "Valeria no viene a clases al día siguiente. Ni al otro."
    "El chat sigue. Cambian los memes, pero el tema es el mismo. Cada vez somos más los que fingimos no ver."

    if aviso_docente:
        "Miss Carolina intenta actuar, pero le llegó poca información y demasiado tarde: casi nada de lo que ocurrió quedó guardado."
    else:
        "Miss Carolina se entera recién cuando los papás de Valeria llaman al colegio. Cuando intenta revisar qué pasó, la mayor parte de los mensajes ya fue borrada."

    "Hay un puesto vacío en el salón. Nadie lo menciona, pero todos lo ven."
    yo "Pude haber hecho algo."
    "Es lo único que logro pensar. Una y otra vez."

    jump historia1_retroalimentacion


# =====================================================
# RETROALIMENTACION
# =====================================================
label historia1_retroalimentacion:

    scene black with fade
    centered "¿Qué pasó y por qué?"

    # --- Día 1 ---
    if conto_secreto:
        "{b}El secreto:{/b} Contárselo a Mateo, aunque fuera sin mala intención, puso en sus manos algo que no era tuyo. El secreto de otra persona solo lo puede contar su dueña."
    else:
        "{b}El secreto:{/b} Guardaste la confianza de Valeria. Eso la hizo sentirse más segura contigo."

    if borro_audio:
        "{b}El audio:{/b} Borraste el audio como prometiste. Así no quedó contenido privado de otra persona esperando a filtrarse."
    else:
        "{b}El audio:{/b} Dejar el audio guardado permitió que se filtrara. Si alguien te pide borrar algo privado, hazlo enseguida: guardarlo te hace responsable de su cuidado."

    # --- Día 2 ---
    if reaccion == "ninguna":
        "{b}Las burlas:{/b} No reaccionaste ni reenviaste nada. No alimentaste el juego."
    elif reaccion == "risa":
        "{b}Las burlas:{/b} Una reacción de risa, aunque sea sin querer, suma a la burla. Quien reacciona también participa."
    else:
        "{b}Las burlas:{/b} Pedir que pararan fue valiente: mostró que no todos estaban de acuerdo. Y es más fácil si luego sumas a un adulto, para no quedarte solo."

    if apoyo:
        "{b}El apoyo:{/b} Escribirle a Valeria en privado le mostró que no estaba sola."
    else:
        "{b}El apoyo:{/b} Dejarla sola dejó pasar una oportunidad. A veces la persona afectada necesita que otro dé el primer paso."

    if conto_secreto:
        if confeso:
            "{b}La verdad:{/b} Reconocer tu error fue difícil, pero ayudó a reparar la confianza."
        else:
            "{b}La verdad:{/b} Mentir parece más fácil en el momento, pero la confianza se rompe más cuando la mentira sale a la luz."

    if tiene_pruebas:
        "{b}Las pruebas:{/b} Guardaste capturas del chat. Son clave para que un adulto pueda actuar."
    else:
        "{b}Las pruebas:{/b} Borrar el chat hizo desaparecer lo que habría ayudado a demostrar lo ocurrido. Antes de salir o borrar, guarda evidencia."

    if aviso_docente:
        "{b}Pedir ayuda:{/b} Contarle a Miss Carolina permitió que el colegio actuara."
    else:
        "{b}Pedir ayuda:{/b} Callar protegió a quien acosaba. Los adultos no ven lo que pasa en los chats si nadie se los cuenta."

    if hablo_familia:
        "{b}La familia:{/b} Acompañar a Valeria a hablar con sus papás hizo que tuviera apoyo también en casa."
    else:
        "{b}La familia:{/b} Pedirle que aguantara dejó a Valeria sola con el problema. La familia es una parte clave del apoyo."

    "{b}Recuerda:{/b} El ciberacoso se enfrenta entre todos: familia, escuela y plataformas."
    "Si te pasa algo parecido, habla con un adulto de confianza: tu docente, tu familia o el DECE (Departamento de Consejería Estudiantil) de tu colegio."

    # --- Final bueno: termina. Final malo: se puede reintentar ---
    if puntos >= 5 and aviso_docente:
        centered "Fin de la historia 1"
        return

    menu:
        "¿Quieres volver a intentarlo?"

        "Volver a intentarlo desde el Día 2":
            python:
                puntos = puntos_dia1
                reaccion = ""
                apoyo = False
                confeso = False
                mintio = False
                tiene_pruebas = False
                aviso_docente = False
                hablo_familia = False
            jump historia1_dia2

        "Terminar":
            centered "Fin de la historia 1"
            return

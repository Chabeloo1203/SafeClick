# =====================================================================
#  SAFECLIC - DEFINICIONES COMPARTIDAS POR LAS 6 HISTORIAS
#  Archivo: game/comun.rpy   (guardar en UTF-8)
#
#  Aquí viven, UNA sola vez, los personajes, los fondos, el movimiento
#  de los sprites y las variables que usan todas las historias.
#  No repitas estas definiciones dentro de las historias.
# =====================================================================


# ---------------------------------------------------------------------
#  Movimiento de los sprites de personajes
# ---------------------------------------------------------------------
transform personaje_normal:
    zoom 2.5
    xalign 0.5
    yalign 1.0


# ---------------------------------------------------------------------
#  Personajes
#  Los colores de Valeria, Mateo, Sofía y Miss Carolina son los de la
#  historia 1, para que se vean igual en todas. Las variables v, m, s y c
#  son atajos para la historia 1.
# ---------------------------------------------------------------------
define narrador = Character(None)
define valeria  = Character("Valeria",       color="#c2578a")
define mateo    = Character("Mateo",         color="#4a7fb5")
define sofia    = Character("Sofía",         color="#d19a3a")
define carolina = Character("Miss Carolina", color="#5a9a6b")
define digi     = Character("Digi",          color="#7C5CFF")
define yo       = Character("[nombre_jugador]", color="#19C3D6")

define v = valeria
define m = mateo
define s = sofia
define c = carolina

# Mensajes de chat: salen en cursiva, sin nombre de personaje.
define chat = Character(None, what_prefix="{i}", what_suffix="{/i}", what_color="#0A7F90")


# ---------------------------------------------------------------------
#  Fondos
# ---------------------------------------------------------------------
image bg patio         = "bg patio.png"
image bg cuarto        = "bg cuarto.png"
image bg cuartonoche   = "bg cuarto oscuro.png"
image bg cuarto oscuro = "bg cuarto oscuro.png"
image bg salon         = "bg salon.png"
image bg entrada       = "bg entrada.png"
image bg terraza       = "bg patio.png"
image bg bar           = "bg bar.png"


# ---------------------------------------------------------------------
#  Variables compartidas
# ---------------------------------------------------------------------
default nombre_jugador = ""     # lo pregunta menu_principal.rpy una sola vez
default nombre         = "Alex" # copia de nombre_jugador que usa la historia 1
default puntos         = 0      # cada historia lo reinicia al empezar

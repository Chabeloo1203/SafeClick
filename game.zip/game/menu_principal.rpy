# =====================================================================
#  SAFECLIC - MENÚ DE HISTORIAS (une las 6 historias)
#  Archivo: game/menu_principal.rpy   (guardar en UTF-8)
#
#  Este archivo es el ÚNICO que tiene "label start".
#  Cada historia se llama con "call", así que al terminar vuelve aquí.
#  Etiquetas de entrada: historia1, historia2, ... historia6
#
#  La pantalla visual del selector está en zz_menu_safeclic.rpy.
# =====================================================================

default historias_completadas = []
default final_mostrado = False

init python:

    HISTORIAS = [
        ("historia1", "Historia 1 - Lo que no se ve"),
        ("historia2", "Historia 2 - Una clave para todo"),
        ("historia3", "Historia 3 - Lo que internet recuerda"),
        ("historia4", "Historia 4 - No es quien dice ser"),
        ("historia5", "Historia 5 - Demasiado bueno para ser cierto"),
        ("historia6", "Historia 6 - Antes de compartir"),
    ]


label start:

    scene black with fade

    # El nombre se pregunta una sola vez para todas las historias
    if nombre_jugador == "":
        $ nombre_jugador = renpy.input("Antes de empezar, ¿cómo te llamas?", length=14).strip()
        if nombre_jugador == "":
            $ nombre_jugador = "Alex"
    $ nombre = nombre_jugador

    digi "¡Hola, [nombre_jugador]! Soy Digi y te voy a acompañar en SafeClic."
    digi "Aquí hay 6 historias sobre cómo cuidarte en internet. Puedes jugarlas en el orden que quieras."

    jump menu_historias


label menu_historias:

    scene bg entrada with dissolve

    call screen selector_historias(historias_completadas)
    $ eleccion = _return

    if eleccion == "salir":
        return

    # Juega la historia elegida y vuelve aquí cuando termine ("return")
    call expression eleccion

    $ numero = int(eleccion[-1])
    if numero not in historias_completadas:
        $ historias_completadas.append(numero)

    if len(historias_completadas) >= 6 and not final_mostrado:
        $ final_mostrado = True
        scene black with fade
        digi "¡Lo lograste, [nombre_jugador]! Completaste las 6 historias."
        digi "Recuerda lo esencial: parar un momento antes de actuar, revisar, y pedir ayuda a un adulto de confianza cuando algo no te cuadre."
        digi "Gracias por jugar SafeClic. Puedes volver a cualquier historia cuando quieras."

    jump menu_historias

# =====================================================================
#  SAFECLIC - HISTORIA 4: "No es quien dice ser"
#  Tema: perfiles falsos, grooming y sextorsión (enfoque preventivo)
#  Archivo: game/historia4.rpy   (guardar en UTF-8)
#
#  Se juega desde menu_principal.rpy con "call historia4".
#  Personajes, fondos, transform y variables compartidas: comun.rpy
# =====================================================================

# --- Personajes propios de esta historia ---
define camila = Character("Camila", color="#e0a030")

# --- Variables de esta historia ---
default respondio_cuenta = False   # le contestó a la cuenta falsa
default cuenta_bloqueada = False
default n_checks         = 0       # cuántas revisiones hizo del perfil
default chk_fecha        = False
default chk_amigos       = False
default chk_foto         = False
default chk_mensaje      = False
default retraso          = False   # se perdió tiempo cumpliendo lo que pedían
default sin_pruebas      = False   # se borraron las pruebas
default camila_cerrada   = False   # Camila se cerró por una mala reacción del jugador


label historia4:

    # Reinicia el estado por si la historia se juega más de una vez
    $ puntos = 0
    $ respondio_cuenta = False
    $ cuenta_bloqueada = False
    $ n_checks = 0
    $ chk_fecha = False
    $ chk_amigos = False
    $ chk_foto = False
    $ chk_mensaje = False
    $ retraso = False
    $ sin_pruebas = False
    $ camila_cerrada = False

    if nombre_jugador == "":
        $ nombre_jugador = renpy.input("Antes de empezar, ¿cómo te llamas?", length=14).strip()
        if nombre_jugador == "":
            $ nombre_jugador = "Alex"

    scene black with fade
    centered "{size=+8}Historia 4{/size}\n{b}No es quien dice ser{/b}"
    centered "Esta historia habla de engaños en internet, chantaje y de cómo pedir ayuda.\nNo muestra imágenes ni escenas explícitas.\nSi algo de esto te está pasando, cuéntaselo hoy a un adulto de confianza."

    scene bg cuarto with fade
    # play music "audio/noche_tranquila.ogg" fadein 1.0

    narrador "Jueves por la noche. Estoy a la mitad de un capítulo cuando suena una notificación: una solicitud de mensaje de una cuenta que no conozco."
    show celular:
        zoom 0.5
        xalign 0.5
        yalign 0.5

    chat "dani.vibes: holaaa!! vi tu foto del concierto, yo también estaba ahí jaja"
    chat "dani.vibes: tenemos gustos parecidos, quería escribirte"
    narrador "La foto de perfil muestra a una persona sonriente, con muy buena pinta."
    yo "Mmm. No me suena de ningún lado."

    menu:
        "¿Qué hago?"

        "Responderle, qué bueno que alguien más fue":
            $ respondio_cuenta = True
            chat "Yo: jaja hola! sí, estuvo increíble"
            chat "dani.vibes: sii!! cuéntame todo, ¿cuál fue tu canción favorita?"
            narrador "Me responde al instante. Y otra vez. Y otra. Mucho interés y mucha prisa para alguien que acabo de conocer."
            narrador "Algo no me cuadra del todo, así que decido mirar su perfil."
            jump h4_perfil_check

        "Mirar su perfil antes de responder":
            $ puntos += 1
            narrador "No me cuesta nada echarle un vistazo antes de contestar."
            jump h4_perfil_check

        "No responder, no la conozco":
            $ puntos += 1
            narrador "Dejo la solicitud sin abrir. Si de verdad nos conocemos, ya me lo dirá alguien."
            jump h4_decision_cuenta


# ---------------------------------------------------------------------
#  Revisión del perfil: el jugador elige qué comprobar
# ---------------------------------------------------------------------
label h4_perfil_check:

    if n_checks >= 4:
        jump h4_checks_fin

    menu:
        "¿Qué compruebo?"

        "Desde cuándo existe la cuenta y cuántas publicaciones tiene" if not chk_fecha:
            $ chk_fecha = True
            $ n_checks += 1
            $ puntos += 1
            narrador "La cuenta se creó hace tres semanas. Tiene once publicaciones, todas muy posadas, y ni un solo comentario de gente real."
            jump h4_perfil_check

        "Si tenemos amigos en común" if not chk_amigos:
            $ chk_amigos = True
            $ n_checks += 1
            $ puntos += 1
            narrador "Ni uno solo. Y su lista de seguidores está casi vacía, aunque dice que fue al mismo concierto que medio colegio."
            jump h4_perfil_check

        "Su foto de perfil, buscándola en internet" if not chk_foto:
            $ chk_foto = True
            $ n_checks += 1
            $ puntos += 1
            narrador "Hago una búsqueda inversa de imágenes. La misma foto aparece en otras tres cuentas con nombres distintos, y también en un banco de imágenes."
            yo "O sea que esa persona ni siquiera existe, o al menos no es esa."
            jump h4_perfil_check

        "Cómo escribe y qué me pide" if not chk_mensaje:
            $ chk_mensaje = True
            $ n_checks += 1
            $ puntos += 1
            narrador "Releo el chat. Habla muy rápido de cosas muy personales y, de pronto, llega otro mensaje."
            chat "dani.vibes: oye, mejor hablemos por otra app, aquí hay mucha gente"
            narrador "Eso me pone alerta. Alguien que apenas me conoce ya quiere sacar la conversación a un lugar más privado."
            jump h4_perfil_check

        "Ya vi suficiente" if n_checks >= 2:
            jump h4_checks_fin

    jump h4_perfil_check


label h4_checks_fin:

    narrador "Con lo que encontré, la cosa está bastante clara: es un perfil falso. Hecho con fotos de otra persona, creado hace poco, y sin conocidos reales."
    jump h4_decision_cuenta


label h4_decision_cuenta:

    menu:
        "¿Qué hago con esa cuenta?"

        "Bloquearla y reportarla":
            $ puntos += 2
            $ cuenta_bloqueada = True
            narrador "La bloqueo y envío el reporte por perfil falso. Ya no me puede escribir."
            chat "Mateo: bien hecho. Esas cuentas suelen escribirle a muchas personas a la vez"

        "Dejarla ahí, sin responder, y seguir con mi vida":
            narrador "Cierro la app. La solicitud se queda ahí, esperando."
            chat "Mateo: mejor bloquéala y repórtala, así no le sirve a nadie más"

        "Seguirle la corriente para ver qué quiere":
            $ puntos -= 1
            narrador "Le sigo la conversación un rato. Cada mensaje suyo es más personal que el anterior."
            narrador "Cuando me pide cambiar de app, cierro todo con un nudo en el estómago. No era buena idea."
            $ cuenta_bloqueada = True
            narrador "La bloqueo, aunque tarde."
    hide celular

    jump h4_cafeteria


# =====================================================================
#  ACTO 2 - CAMILA
# =====================================================================
label h4_cafeteria:

    scene bg bar with fade
    # play music "audio/colegio_recreo.ogg" fadein 1.0

    show camila distraida at personaje_normal
    narrador "Viernes, recreo. Camila siempre es la primera en llegar a la cafetería, haciendo bromas. Hoy lleva diez minutos sentada sin tocar su jugo, con el celular boca abajo sobre la mesa."
    hide camila distraida
    show camila nerviosa at personaje_normal
    narrador "Vibra. Ella pega un salto, lo voltea, lee... y se pone pálida."
    hide camila nerviosa
    show camila decaida at personaje_normal
    narrador "Valeria y Sofía hablan al lado, sin darse cuenta. Yo sí."
    

    menu:
        "¿Qué hago?"

        "Preguntarle delante de todas qué le pasa, hasta que conteste":
            $ puntos -= 1
            show camila distraida at personaje_normal
            yo "Camila, ¿qué te pasa? Ya, dime."
            hide camila distraida 
            show camila nerviosa at personaje_normal
            camila "Nada. Déjame."
            hide camila nerviosa
            narrador "Camila agarra su mochila y se va. Valeria me mira con cara de «eso no ayudó»."
            narrador "Tiene razón. Me quedo pensando en cómo hacerlo mejor."
            $ camila_cerrada = True

        "Esperar a que quede sola y preguntarle con calma, sin presionar":
            $ puntos += 1
            show camila distraida at personaje_normal
            narrador "No digo nada ahora. Cuando suena el timbre y todas se van, me quedo cerca y espero."
            hide camila distraida
            $ camila_cerrada = False

        "Mirarle el celular cuando se distraiga":
            $ puntos -= 1
            show camila distraida at personaje_normal
            narrador "Estiro la mano para mirar la pantalla. Camila lo agarra de golpe."
            hide camila distraida 
            show camila enojada at personaje_normal
            camila "¡¿Qué haces?! Eso no se hace."
            hide camila enojada
            show camila molesta at personaje_normal
            yo "Perdón, perdón. Tienes razón."
            hide camila molesta
            narrador "Se va con los ojos brillantes. Acabo de empeorarlo."
            $ camila_cerrada = True

    hide camila decaida
    jump h4_terraza


label h4_terraza:

    scene bg terraza with dissolve

    show camila decaida at personaje_normal
    narrador "La encuentro más tarde en la terraza, sentada sola, abrazando su mochila."

    if camila_cerrada:
        show camila molesta at personaje_normal
        yo "Camila... perdón por antes. No quise presionarte. Solo quería saber si estás bien."
        hide camila molesta
        show camila avergonzada at personaje_normal
        camila "Lo sé. Perdón yo también. Es que... no sé cómo decirlo."
        hide camila avergonzada
    else:
        show camila distraida at personaje_normal
        yo "Oye. Desde el recreo te noto muy distinta. No tienes que contarme nada, pero aquí estoy."
        hide camila distraida
        show camila pregunta at personaje_normal
        camila "¿Tanto se nota?"
        hide camila pregunta
    hide camila decaida

    show camila distraida at personaje_normal
    narrador "Se queda callada un buen rato. Después empieza a hablar muy bajito."
    hide camila distraida

    show camila nerviosa at personaje_normal
    camila "Hace unos meses empecé a hablar con una cuenta. Me escuchaba como nadie. Pensé que era de mi edad."
    camila "Un día me pidió una foto. No te voy a decir cuál. Se la mandé."
    camila "Hoy me escribió que, si no le mando más o le deposito plata, se la va a mandar a todo mi curso."
    camila "La cuenta se llama dani.vibes."
    hide camila nerviosa
    show camila avergonzada at personaje_normal

    narrador "Me quedo sin palabras. Es la misma cuenta que me escribió a mí."

    if cuenta_bloqueada:
        show camila sorprendida at personaje_normal
        yo "A mí también me escribió esa cuenta. Revisé su perfil: las fotos son de otra persona y la cuenta es nueva. Ni siquiera sabemos quién está detrás."
        hide camila sorprendida
    else:
        show camila sorprendida at personaje_normal
        yo "A mí también me escribió esa cuenta, Camila. Es la misma."
        hide camila sorprendida
        show camila nerviosa at personaje_normal
        camila "¿En serio?"
        yo "Sí. Y ahora creo que no es quien dice ser."
        hide camila nerviosa

    hide camila avergonzada
    show camila nerviosa at personaje_normal
    camila "Ya no sé ni quién es. Ni cuántos años tiene. Y me da muchísima vergüenza."

    # ----- Cómo reacciona el jugador -----
    menu:
        "No sé qué decirle. ¿Qué le digo?"

        "Que no es su culpa, y que me alegra que me lo haya contado":
            $ puntos += 1
            show camila avergonzada at personaje_normal
            yo "No es tu culpa, Camila. En serio. Me alegra muchísimo que me lo hayas dicho."
            narrador "Se le escapa un suspiro largo, como si se hubiera quitado una mochila de encima."
            hide camila avergonzada

        "Preguntarle por qué mandó esa foto":
            $ puntos -= 1
            show camila avergonzada at personaje_normal
            yo "¿Y por qué le mandaste eso?"
            hide camila avergonzada
            show camila nerviosa at personaje_normal
            camila "Ya sé que fue tonto. No me lo digas, por favor."
            hide camila nerviosa
            show camila avergonzada at personaje_normal
            yo "Perdón. No quise decir eso. No es lo importante ahora, y te creo."
            narrador "Casi se cierra por completo. Pero no se va."
            hide camila avergonzada

        "Prometerle que no se lo voy a contar a nadie":
            $ puntos -= 1
            show camila avergonzada at personaje_normal
            yo "Te lo prometo, no se lo cuento a nadie."
            hide camila avergonzada
            show camila sorprendida at personaje_normal
            narrador "Lo digo sin pensar. Y dos minutos después me doy cuenta de que no puedo cumplirlo."
            hide camila sorprendida
            show camila nerviosa at personaje_normal
            yo "Camila... perdón, no debí prometerte eso. Esto es demasiado grande para dos."
            hide camila nerviosa
            show camila pregunta at personaje_normal
            camila "Entonces... ¿me vas a acusar?"
            yo "No te voy a acusar. Quiero que alguien que sepa cómo se arregla esto nos ayude."
            hide camila pregunta

    hide camila nerviosa
    show camila hablando at personaje_normal
    camila "Y ahora, ¿qué hago? Me dio plazo hasta esta noche."
    hide camila hablando
    show camila pregunta at personaje_normal

    menu:
        "Tengo que decir algo ahora. ¿Qué le propongo?"

        "Que haga lo que pide para que la deje en paz":
            $ puntos -= 2
            $ retraso = True
            show camila distraida at personaje_normal
            yo "A lo mejor si le das lo que pide, se calma."
            hide camila distraida
            narrador "Camila lo hace. Dos horas después me escribe llorando: no era el final. Ahora pide más."
            show celular :
                zoom 0.5
                xalign 0.5
                yalign 0.5
            yo "Perdón, Camila. Fue mala idea. Eso nunca termina: cada vez piden más."
            camila "Ya lo sé... ya lo sé."
            hide celular
            narrador "Perdimos tiempo, y a ella le costó más. Pero todavía podemos pedir ayuda."

        "Que no le responda más, que guardemos todas las pruebas y se lo contemos a Miss Carolina":
            $ puntos += 3
            show camila distraida at personaje_normal
            yo "No le contestes más y no le mandes nada. Vamos a guardar todo lo que escribió, con el nombre de la cuenta, el link del perfil y las fechas."
            hide camila distraida
            show camila sorprendida at personaje_normal
            yo "Y después se lo contamos a Miss Carolina. Ella sabe qué hacer."
            hide camila sorprendida
            show camila nerviosa at personaje_normal
            camila "¿Y si se enoja?"
            hide camila nerviosa
            show camila avergonzada at personaje_normal
            yo "Esa persona ya está enojada. Lo que nos toca es no darle más y guardarlo todo."
            hide camila avergonzada
            narrador "Hacemos las capturas con calma: el perfil, los mensajes, las amenazas, las fechas. Guardamos todo en un lugar que esa cuenta no puede tocar."

        "Contestarle con amenazas para que se asuste":
            $ puntos -= 1
            show camila distraida at personaje_normal
            yo "¿Y si le escribimos algo fuerte, que lo vamos a denunciar?"
            hide camila distraida
            show camila sorprendida at personaje_normal
            narrador "Escribimos algo fuerte. Responde con una risa y con un mensaje peor."
            hide camila sorprendida
            show camila nerviosa at personaje_normal
            yo "Mala idea. Eso solo lo alimenta. Mejor no le damos más atención."
            narrador "Camila está más asustada que antes."
            hide camila nerviosa

        "Borrar el chat y la cuenta para que desaparezca todo":
            $ puntos -= 1
            $ sin_pruebas = True
            show camila distraida at personaje_normal 
            yo "Borra todo, a lo mejor así desaparece."
            hide camila distraida
            show camila sorprendida at personaje_normal
            narrador "Camila borra el chat y bloquea la cuenta. Respiramos... un minuto."
            hide camila sorprendida
            show camila nerviosa at personaje_normal
            narrador "Esa tarde llega otro mensaje desde otro perfil: «Yo sí guardé todo»."
            yo "Ay, no. Perdimos nuestras pruebas, y quien amenaza conserva las suyas."
            hide camila nerviosa

    hide camila pregunta
    yo "Ahora sí: vamos con Miss Carolina. Yo voy contigo."

    jump h4_carolina


# =====================================================================
#  CON MISS CAROLINA
# =====================================================================
label h4_carolina:

    scene bg salon with dissolve

    show carolina neutro at personaje_normal
    narrador "Miss Carolina nos recibe en su salón, cierra la puerta con suavidad y se sienta cerca. No pregunta ni apura. Solo espera."
    hide carolina neutro
    show camila avergonzada at personaje_normal
    narrador "Camila cuenta todo otra vez, más despacio. Yo me quedo a su lado."
    hide camila avergonzada

    show carolina hablando at personaje_normal
    carolina "Camila, gracias por contármelo. Lo que te pasó tiene un nombre: sextorsión. Y la responsabilidad es de quien te chantajea, no tuya."
    hide carolina hablando
    show camila avergonzada at personaje_normal
    camila "Me da vergüenza que lo sepan en mi casa."
    hide camila avergonzada
    show carolina hablando at personaje_normal
    carolina "Te entiendo. Pero la vergüenza es justo lo que esa persona quiere que sientas para que no hables. Hablar es lo que le quita el poder."

    if sin_pruebas:
        show carolina hablando at personaje_normal
        carolina "Se perdió parte del chat, pero eso no cambia lo importante: se puede reportar la cuenta y hay cosas que todavía se pueden recuperar. Eso lo vemos ahora."
        hide carolina hablando
    elif retraso:
        show carolina hablando at personaje_normal
        carolina "Se tardaron un poco, pero lo importante es que están aquí. Todavía estamos a tiempo."
        hide carolina hablando
    else:
        show carolina hablando at personaje_normal
        carolina "Hicieron algo muy importante: guardaron todo y no le dieron nada más. Eso vale muchísimo."
        hide carolina hablando

    carolina "Hay tres cosas que quiero que recuerden. La primera: no se paga y no se manda nada más, porque el chantaje no termina. La segunda: no se borra nada, hasta que un adulto lo revise. La tercera: dejen de contestarle."
    carolina "Voy a avisar al DECE y vamos a llamar a tu familia, juntas. El colegio tiene un protocolo para estos casos y, si corresponde, se hace la denuncia ante la Fiscalía; la DINAPEN trabaja con adolescentes."
    hide carolina hablando
    show camila nerviosa at personaje_normal
    camila "Mi mamá se va a enojar."
    hide camila nerviosa
    show carolina hablando at personaje_normal
    carolina "Puede que se asuste o se enoje al principio. Pero lo que va a querer es protegerte. Y vamos contigo."

    carolina "Y para que lo sepan, por si alguna vez escuchan la palabra: grooming es cuando una persona adulta engaña a un menor, muchas veces fingiendo ser de su edad, para ganarse su confianza y conseguir algo de él o de ella. El perfil falso es el disfraz."

    hide carolina hablando
    show camila avergonzada at personaje_normal
    narrador "Camila me aprieta la mano. Le hago un gesto de que aquí estoy."
    hide camila avergonzada

    show carolina hablando at personaje_normal
    carolina "[nombre_jugador], hiciste lo más difícil: escucharla y traerla hasta aquí. Eso se llama ser un buen amigo, o una buena amiga, de verdad."
    hide carolina hablando

    jump h4_final


# =====================================================================
#  EL FINAL
# =====================================================================
label h4_final:

    scene bg terraza with fade
    # play music "audio/final_calma.ogg" fadein 1.0

    narrador "Unos días después, Camila y yo nos sentamos otra vez en la terraza. Esta vez ella se ve cansada, pero ya no está tan sola."

    if puntos >= 8:
        jump h4_final_bueno
    elif puntos >= 4:
        jump h4_final_regular
    else:
        jump h4_final_malo


label h4_final_bueno:
    scene black with fade
    centered "Final bueno"

    show camila hablando at personaje_normal
    camila "Mi mamá lloró un poco. Después me abrazó y no me soltó por un rato largo."
    camila "La cuenta dejó de existir después de los reportes. El caso está en manos de las autoridades. Y voy a hablar con la psicóloga del DECE."
    hide camila hablando at personaje_normal
    show camila neutro at personaje_normal
    yo "No todo se arregla de un día para otro."
    show camila hablando at personaje_normal
    camila "Ya sé. Pero ya no me da miedo cada vez que suena el celular."
    hide camila hablando

    narrador "FIN: Pedir ayuda a tiempo cambia todo. Quien chantajea cuenta con tu silencio, y tú le quitas ese poder."
    jump h4_digi


label h4_final_regular:
    scene black with fade
    centered "Final regular"

    show camila hablando at personaje_normal
    camila "Mi familia ya lo sabe y el colegio activó el protocolo. Todavía hay cosas por resolver, y me da ansiedad."
    hide camila hablando
    show camila hablando at personaje_normal
    yo "Estoy contigo. Todo lo que haga falta."
    hide camila hablando
    show camila hablando at personaje_normal
    camila "Gracias. Ojalá se lo hubiera contado a alguien antes."
    hide camila hablando

    narrador "FIN: Algunas decisiones costaron más de lo necesario, pero hay adultos ayudando y Camila ya no está sola."
    jump h4_digi


label h4_final_malo:
    scene black with fade
    centered "Final malo"

    show camila hablando at personaje_normal
    camila "Todo costó más de lo que debió. Perdimos tiempo y perdimos pruebas."
    hide camila hablando
    show camila neutro at personaje_normal
    yo "Lo sé. Pero tampoco estás sola, y ahora hay adultos ayudando."
    hide camila neutro
    show camila hablando  at personaje_normal
    camila "Sí. Aunque a veces todavía me da miedo."
    hide camila hablando
    show camila neutro at personaje_normal
    yo "Es normal tener miedo. Se va pasando, poco a poco."
    hide camila neutro

    narrador "FIN: Callar y esperar le da fuerza a quien amenaza. Pedir ayuda desde el principio habría ahorrado mucho."
    jump h4_digi


# ---------------------------------------------------------------------
#  Cierre con Digi: resumen y opción de repetir
# ---------------------------------------------------------------------
label h4_digi:

    scene black with fade

    digi "¡Hola! Soy Digi. Antes de cerrar esta historia, te dejo cinco cosas para llevarte."
    digi "Uno: no todas las personas son quienes dicen ser. Antes de aceptar a alguien, revisa su perfil: cuándo se creó, qué publica, si tienen conocidos en común y si su foto aparece en otros lados."
    digi "Dos: desconfía de quien se apura a ganarse tu confianza, te pide guardar secretos, quiere pasar a otra app o te pide fotos."
    digi "Tres: si te chantajean, no pagues ni mandes nada más. Guarda las pruebas, deja de responder y cuéntaselo hoy a un adulto de confianza."
    digi "Cuatro: si un amigo o una amiga te cuenta algo así, no prometas guardar el secreto ni lo culpes. Escúchalo y acompáñalo a pedir ayuda."
    digi "Cinco: la culpa nunca es de quien fue engañado. Es de quien engaña."
    digi "Si te está pasando algo así, habla hoy con un adulto de confianza o con el DECE de tu colegio. También se puede denunciar ante la Fiscalía o con la DINAPEN."

    menu:
        "¿Qué quieres hacer ahora?"

        "Volver a jugar esta historia":
            jump historia4

        "Terminar":
            return

# =====================================================================
#  SAFECLIC - MENÚ PRINCIPAL ESTÉTICO, SELECTOR DE HISTORIAS Y CRÉDITOS
#  Archivo: game/zz_menu_safeclic.rpy   (guardar en UTF-8)
#
#  El nombre empieza por "zz_" y lleva "init offset" para que este
#  "screen main_menu" se cargue DESPUÉS del que trae Ren'Py en
#  screens.rpy y lo reemplace. Aun así, es mejor borrar o comentar el
#  "screen main_menu():" original de screens.rpy.
#
#  Imágenes que usa (carpeta game/images/menu/):
#     menu_safeclic.png   dibujo completo del menú (fondo, logo y botones)
#     hover_menu.png      borde que se ilumina al pasar el mouse
#     pill_idle.png, pill_hover_sel.png, pill_done.png   botones del selector
# =====================================================================

init offset = 10

init python:

    # Convierten coordenadas del dibujo original (1672 x 941) a píxeles
    # de tu pantalla, para que funcione con cualquier resolución 16:9.
    def mx(x):
        return int(round(x * config.screen_width / 1672.0))

    def my(y):
        return int(round(y * config.screen_height / 941.0))


# ---------------------------------------------------------------------
#  MENÚ PRINCIPAL: el dibujo completo + botones invisibles encima
# ---------------------------------------------------------------------
screen main_menu():

    tag menu

    add "images/menu/menu_safeclic.png" xysize (config.screen_width, config.screen_height)

    # Última partida guardada (None si todavía no hay ninguna)
    $ ultimo = renpy.newest_slot()

    # (x, y, ancho, alto) medidos sobre el dibujo, y la acción de cada botón
    $ botones = [
        (157, 404, 418, 71, Start()),
        (157, 482, 418, 71, FileLoad(ultimo, confirm=False) if ultimo else ShowMenu("load")),
        (157, 559, 418, 70, ShowMenu("load")),
        (157, 634, 418, 70, ShowMenu("preferences")),
        (157, 710, 418, 68, ShowMenu("creditos")),
        (157, 784, 418, 70, Quit(confirm=False)),
    ]

    for x, y, w, h, accion in botones:
        button:
            pos (mx(x), my(y))
            xysize (mx(w), my(h))
            background None
            hover_background Frame("images/menu/hover_menu.png", 48, 48)
            action accion
            null


# ---------------------------------------------------------------------
#  SELECTOR DE HISTORIAS (lo llama menu_principal.rpy)
#  Devuelve la etiqueta de la historia elegida o "salir".
# ---------------------------------------------------------------------
screen selector_historias(completadas):

    modal True
    zorder 100

    add Solid("#0a1d4aa8")

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 16

        text "Elige una historia":
            size 68
            color "#ffffff"
            outlines [ (5, "#1b2f6b", 0, 0) ]
            xalign 0.5

        text "Aprende · Cuídate · Conéctate":
            size 30
            color "#d8ecff"
            xalign 0.5

        null height 18

        for etiqueta, titulo in HISTORIAS:

            $ hecha = int(etiqueta[-1]) in completadas

            button:
                xsize 1040
                ysize 90
                xalign 0.5
                background Frame("images/menu/pill_done.png" if hecha else "images/menu/pill_idle.png", 46, 46)
                hover_background Frame("images/menu/pill_hover_sel.png", 46, 46)
                action Return(etiqueta)

                hbox:
                    xalign 0.5
                    yalign 0.5
                    spacing 26

                    text titulo size 34 color "#14305c" yalign 0.5

                    if hecha:
                        text "Completada" size 26 color "#0A7F90" yalign 0.5

        null height 14

        textbutton "Volver al menú principal":
            xalign 0.5
            text_size 30
            text_color "#ffffff"
            text_hover_color "#ffe28a"
            text_outlines [ (3, "#1b2f6b", 0, 0) ]
            action Return("salir")


# ---------------------------------------------------------------------
#  CRÉDITOS (botón «Créditos» del menú principal)
#  Cambia los textos que dicen "AQUÍ" por los tuyos.
# ---------------------------------------------------------------------
screen creditos():

    tag menu

    use game_menu(_("Créditos"), scroll="viewport"):

        style_prefix "about"

        vbox:
            spacing 12

            label "SafeClic"
            text "Aprende · Cuídate · Conéctate"

            null height 20

            text "Novela visual educativa para promover el uso responsable de las redes sociales y la seguridad digital."

            null height 20

            text "Autoría y guion: TU NOMBRE AQUÍ"
            text "Tutoría académica: NOMBRE DE TU TUTOR O TUTORA AQUÍ"
            text "Institución: NOMBRE DE LA INSTITUCIÓN AQUÍ"

            null height 20

            text "Ilustraciones, fondos y la mascota Digi: generados con inteligencia artificial (indica aquí la herramienta usada)."
            text "Hecho con Ren'Py [renpy.version_only]."

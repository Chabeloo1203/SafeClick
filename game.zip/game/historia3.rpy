# =====================================================================
#  SAFECLIC - HISTORIA 3: "Lo que internet recuerda"
#  Tema: huella digital, qué publicar y qué no, privacidad y doxxing
#  Archivo: game/historia3.rpy   (guardar en UTF-8)
#
#  Se juega desde menu_principal.rpy con "call historia3".
#  Personajes, fondos, transform y variables compartidas: comun.rpy
# =====================================================================

# --- Variables de esta historia ---
default expuso_casa      = False   # subió una foto donde se ve su casa/calle
default expuso_colegio   = False   # subió una foto donde se ve el colegio
default insulto          = False   # contestó con un insulto en los comentarios
default represalia       = False   # quiso publicar datos de quien lo hizo
default familia_enterada = False
default priv_perfil      = False
default priv_ubicacion   = False
default priv_fotos       = False
default priv_etiquetas   = False
default priv_busqueda    = False
default n_hechos         = 0       # cuántos ajustes de privacidad hizo


label historia3:

    # Reinicia el estado por si la historia se juega más de una vez
    $ puntos = 0
    $ expuso_casa = False
    $ expuso_colegio = False
    $ insulto = False
    $ represalia = False
    $ familia_enterada = False
    $ priv_perfil = False
    $ priv_ubicacion = False
    $ priv_fotos = False
    $ priv_etiquetas = False
    $ priv_busqueda = False
    $ n_hechos = 0

    if nombre_jugador == "":
        $ nombre_jugador = renpy.input("Antes de empezar, ¿cómo te llamas?", length=14).strip()
        if nombre_jugador == "":
            $ nombre_jugador = "Alex"

    scene black with fade
    centered "{size=+8}Historia 3{/size}\n{b}Lo que internet recuerda{/b}"

    scene bg cuarto with fade
    # play music "audio/tarde_tranquila.ogg" fadein 1.0

    narrador "Domingo por la tarde. Ya terminé los deberes (casi) y tengo tres fotos en la galería que quiero subir antes de que se me pase el momento."
    show celular :
        zoom 0.5
        xalign 0.5
        yalign 0.5

    chat "Sofía: sube la del colegio!! quedó brutal"
    chat "Mateo: y la de tu perro, esa es la mejor jaja"
    narrador "Las reviso una por una."

    # ----- Foto 1: la casa -----
    narrador "La primera la tomé hoy en la puerta de mi casa. Salgo sonriendo y, detrás de mí, se ven el número de la casa y el letrero de la calle. El celular me sugiere agregar la ubicación."

    menu:
        "¿Cómo la subo?"

        "Tal cual, con la ubicación":
            $ expuso_casa = True
            narrador "Subo la foto con todo: casa, calle y ubicación. Total, es mi casa."

        "Recortada, sin el número ni la calle, y sin ubicación":
            $ puntos += 1
            narrador "La recorto para que solo se vea mi cara y un pedazo de pared. Quito la ubicación. Sigue siendo una buena foto."

        "Mejor no la subo":
            $ puntos += 1
            narrador "Pensándolo bien, no tengo por qué enseñar mi puerta a nadie. La dejo en la galería."

    # ----- Foto 2: el colegio -----
    narrador "La segunda es de la semana pasada: Valeria, Sofía y yo con el uniforme, justo frente al letrero del colegio. Salimos con las caras de siempre."

    menu:
        "¿Cómo la subo?"

        "Con el colegio etiquetado, para que se vea bien":
            $ expuso_colegio = True
            narrador "Subo la foto con la etiqueta del colegio y todo."

        "Solo para mis mejores amigos":
            $ puntos += 1
            narrador "Uso la lista de mejores amigos. Así solo la ven los que de verdad conozco."

        "Les pregunto a Valeria y a Sofía si les parece bien, y la subo sin etiquetar el colegio":
            $ puntos += 1
            chat "Yo: ¿les parece si subo la foto del colegio? No etiqueto el lugar"
            chat "Valeria: sí dale, gracias por preguntar"
            chat "Sofía: obvio, quedamos divinas"

    # ----- Foto 3: el perro -----
    narrador "La tercera es de mi perro, Toby, dormido en el sofá con cara de que la vida es dura. Esa la subo sin pensarlo."
    chat "Mateo: esa sí está bien. Eso sí, no uses «Toby» de contraseña ni de pregunta de seguridad, que es lo primero que prueban"
    yo "Jaja, ya sé, ya sé."

    narrador "Publico. En diez minutos ya tengo corazones, comentarios y gente que no conozco mirando mis historias."
    narrador "Mi cuenta es pública desde siempre. Nunca lo pensé mucho: así me ve más gente. Es lo que hace todo el mundo, ¿no?"


# =====================================================================
#  ACTO 2 - EL COMENTARIO
# =====================================================================
label h3_comentario:

    scene bg cuarto oscuro with dissolve

    narrador "Lunes por la noche. Estoy viendo un video viral sobre una discusión por el partido del fin de semana, con trescientos mil comentarios y cada uno más acalorado que el anterior."
    narrador "Dejo uno que me parece graciosísimo."
    chat "Yo: el árbitro necesitaba lentes y un GPS"
    narrador "Me llegan corazones. Y también una respuesta de una cuenta sin foto."
    chat "@sin_filtro_77: Qué chistoso. Vuelve cuando sepas de fútbol."

    menu:
        "Me da rabia. ¿Qué hago?"

        "Contestarle con un insulto bien filoso":
            $ insulto = True
            $ puntos -= 1
            narrador "Escribo algo que prefiero no repetir. Lo mando antes de pensarlo dos veces."
            chat "@sin_filtro_77: Ya veremos qué tan valiente eres."

        "Contestarle con calma y no seguir":
            chat "Yo: jaja cada quien su opinión"
            narrador "No responde. Por ahora."

        "No contestar y silenciar ese hilo":
            $ puntos += 1
            narrador "Silencio las notificaciones de ese comentario. Si quiere seguir hablando solo, que hable solo."

    narrador "Cierro la app y me olvido del asunto. Mañana ni me voy a acordar."
    hide celular

# =====================================================================
#  ACTO 3 - LA PUBLICACIÓN
# =====================================================================
label h3_filtracion:

    scene bg entrada with fade
    # play music "audio/tension.ogg" fadein 1.0

    narrador "Martes, 7:05. Apenas cruzo la puerta del colegio, Valeria me agarra del brazo."
    show valeria nerviosa2 at personaje_normal
    valeria "[nombre_jugador], ven. Tienes que ver esto. Ahora."
    hide valeria nerviosa2 at personaje_normal
    show celular :
        zoom 0.5
        xalign 0.5
        yalign 0.5

    narrador "Me muestra su celular. Es una publicación de una cuenta anónima, sin foto. Dice que la subieron anoche."

    chat "Publicación anónima: Esta es la cuenta de [nombre_jugador], que opina de todo sin saber nada."

    if expuso_colegio:
        chat "Publicación anónima: Estudia en el colegio de la foto, uniforme incluido. Miren el letrero."

    if expuso_casa:
        chat "Publicación anónima: Y vive aquí. Se ve la casa y la calle en su foto de la puerta. Si pasan por ahí, díganle algo."

    if not expuso_colegio and not expuso_casa:
        chat "Publicación anónima: Miren su foto de perfil, para que sepan a quién le hablan."

    chat "Publicación anónima: Compartan."
    hide celular
    narrador "Se me corta la respiración. Me sudan las manos."
    show valeria nerviosa2 at personaje_normal
    valeria "Ya la reenviaron en varios grupos, hasta de otros colegios. Mateo ya está en la cafetería, vamos."
    hide valeria nerviosa2
    scene bg bar with dissolve

    show mateo hablando at personaje_normal
    mateo "Respira, [nombre_jugador]. A ver, mírame: esto tiene nombre, se llama doxxing. Es cuando alguien junta datos tuyos de internet y los publica para exponerte o hacerte sentir mal."
    hide mateo hablando 
    show mateo neutro at personaje_normal
    yo "¿Y cómo consiguió todo eso?"
    hide mateo neutro
    show mateo hablando  at personaje_normal
    mateo "De lo que está público. Tu foto con el uniforme, tu foto en la puerta de tu casa, tu cuenta abierta para cualquiera... Nadie tuvo que hackear nada."
    hide mateo hablando
    
    if insulto:
        show mateo hablando at personaje_normal
        mateo "Y no te voy a mentir: contestar con un insulto no ayudó. Pero tampoco es la causa. Esa gente busca cualquier excusa."
        hide mateo hablando

    else:
        show mateo hablando at personaje_normal
        mateo "Y que quede claro: esto no es por tu comentario. Esa gente busca cualquier excusa."
        hide mateo hablando

    if expuso_casa:
        show mateo neutro at personaje_normal
        narrador "Pienso en la foto de la puerta y siento un frío en el estómago. ¿Y si alguien pasa por mi calle?"
        hide mateo neutro
        show mateo hablando at personaje_normal
        mateo "Eso, justo, es lo que más me preocupa. No es para entrar en pánico, pero sí hay que avisar a un adulto hoy mismo."
        hide mateo hablando

    show mateo neutro at personaje_normal
    menu:
        "Tengo el celular en la mano y el corazón a mil. ¿Qué hago primero?"

        "Publicar yo también los datos de esa cuenta, para que sienta lo que se siente":
            $ represalia = True
            $ puntos -= 1
            narrador "Empiezo a escribir. Tengo rabia y las manos temblando."
            show mateo sorprendido at personaje_normal
            mateo "¡Para! Ni se te ocurra. Eso es hacer exactamente lo mismo que te hicieron, y además puedes equivocarte de persona."
            hide mateo sorprendido
            show mateo hablando at personaje_normal
            mateo "Si publicas datos de alguien que no es, ahora tendrías dos problemas. Y a quien pueden sancionar es a ti."
            hide mateo hablando
            show mateo neutro at personaje_normal
            narrador "Borro lo que escribí. Me tiemblan los pulgares, pero tiene sentido."
            hide mateo neutro

        "Capturar todo con fecha y link, reportar la publicación y bloquear la cuenta":
            $ puntos += 2
            show mateo neutro at personaje_normal
            yo "Primero las capturas, con la hora y el link. Después reporto la publicación por exponer datos personales, y bloqueo la cuenta."
            hide mateo neutro
            show mateo hablando at personaje_normal
            mateo "Exacto. Primero la prueba. Si reportas primero y borran la publicación, te quedas sin evidencia."
            hide mateo hablando

        "Borrar mi cuenta ahora mismo y desaparecer":
            show mateo neutro at personaje_normal
            narrador "Se me cruza la idea de borrarlo todo y empezar de cero."
            hide mateo neutro
            show mateo hablando at personaje_normal
            mateo "Te entiendo, de verdad. Pero borrar tu cuenta no borra lo que ya copiaron, y pierdes la evidencia. Mejor guarda todo primero y después decides."
            hide mateo hablando
            show mateo neutro at personaje_normal
            narrador "Respiro hondo y empiezo a tomar capturas, una por una."
            hide mateo neutro
    hide mateo neutro

    show mateo hablando at personaje_normal
    mateo "Y otra cosa: no la reenvíes, ni siquiera para quejarte. Cada reenvío la hace más grande."
    hide mateo hablando
    show valeria hablando at personaje_normal
    valeria "Vamos con Miss Carolina. Ella sabe qué hacer."
    hide valeria hablando

    jump h3_carolina


# =====================================================================
#  CON MISS CAROLINA
# =====================================================================
label h3_carolina:

    scene bg salon with dissolve
    show carolina hablando at personaje_normal
    carolina "Pasa, [nombre_jugador]. Valeria me escribió. Primero lo primero: tú no hiciste nada malo. Lo hizo quien publicó esos datos, no quien los tenía en su perfil."
    hide carolina hablando 
    show carolina neutro at personaje_normal
    yo "Es que siento que yo lo permití. Subí esas fotos."
    hide carolina neutro
    show carolina hablando at personaje_normal
    carolina "Subiste fotos normales, como cualquiera. Lo que vamos a hacer es aprender qué conviene dejar de mostrar, y no tendrás que cargarlo en soledad. Muéstrame lo que guardaste."
    hide carolina hablando
    show carolina neutro at personaje_normal
    narrador "Le enseño las capturas: la publicación, la hora, el nombre de la cuenta y el link. Ella asiente despacio."
    hide carolina neutro
    show carolina hablando at personaje_normal
    carolina "Muy bien. Esto sirve para el reporte y, si hiciera falta, para una denuncia."

    # ----- Adulto de confianza -----
    menu:
        carolina "¿Tu familia ya sabe?"

        "No todavía. Podemos llamar a mi mamá ahora":
            $ puntos += 2
            $ familia_enterada = True
            show carolina hablando at personaje_normal
            carolina "Eso es lo mejor que puedes hacer. Voy a hablar yo primero, y después te paso."
            hide carolina hablando
            show carolina neutro at personaje_normal
            narrador "Mamá contesta al segundo timbre, preocupada. Miss Carolina le explica con calma. Después me pasa el teléfono."
            narrador "Mamá se queda un momento en silencio. Luego dice: «Voy para allá. Gracias por contármelo»."
            narrador "Es raro, pero tener a alguien de mi lado cambia todo el cuerpo."
            hide carolina neutro

        "Mejor no, no quiero preocuparla":
            show carolina hablando at personaje_normal
            carolina "Entiendo que no quieras preocuparla. Pero esto no es para que lo cargues sin apoyo, y si crece, es mejor que lo sepa por ti y no por un tercero."
            carolina "No te voy a presionar ahora mismo. Pero te pido que esta tarde se lo cuentes, ¿sí? Si quieres, te acompaño o te ayudo a pensar cómo decírselo."
            hide carolina hablando
            show carolina neutro at personaje_normal
            yo "Está bien... esta tarde."
            hide carolina neutro
    hide carolina hablando

    if expuso_casa:
        show carolina hablando at personaje_normal
        carolina "Como en la publicación se ve tu casa, esto puede llegar a una denuncia. La Fiscalía recibe este tipo de casos, y la DINAPEN trabaja con adolescentes. Eso lo decide tu familia con orientación, pero tiene que saberlo."
        hide carolina hablando

    # ----- Revisión de privacidad -----
    show carolina hablando at personaje_normal
    carolina "Ahora, vamos con lo que sí está en tus manos: revisar qué tan abierta tienes tu cuenta. Elige por dónde empezamos."
    hide carolina hablando

    jump h3_checkup


# ---------------------------------------------------------------------
#  Revisión de privacidad: el jugador elige qué ajustes hace
# ---------------------------------------------------------------------
label h3_checkup:

    if n_hechos >= 5:
        jump h3_checkup_fin
    show carolina pregunta at personaje_normal
    menu:
        carolina "¿Qué revisamos?"

        "Poner mi perfil en privado" if not priv_perfil:
            $ priv_perfil = True
            $ n_hechos += 1
            $ puntos += 1
            show carolina neutro at personaje_normal
            narrador "Entro a Configuración, luego a Privacidad de la cuenta, y la cambio a privada. Desde ahora solo ve mis publicaciones quien yo acepte."
            hide carolina neutro
            show carolina hablando at personaje_normal
            carolina "Y revisa tu lista de seguidores: deja solo a quienes conoces de verdad. Si no sabes quién es, no hace falta que te siga."
            hide carolina hablando
            jump h3_checkup

        "Quitar la ubicación de mis fotos y publicaciones" if not priv_ubicacion:
            $ priv_ubicacion = True
            $ n_hechos += 1
            $ puntos += 1
            show carolina neutro at personaje_normal
            narrador "Desactivo la ubicación en la cámara y reviso mis publicaciones. Tres tenían etiqueta de lugar. Las quito."
            hide carolina neutro
            show carolina hablando at personaje_normal
            carolina "Ojo: a veces la foto trae la ubicación guardada por dentro. Apaga la ubicación en la cámara, así no se guarda desde el principio."
            hide carolina hablando
            jump h3_checkup

        "Revisar mis fotos antiguas, de arriba abajo" if not priv_fotos:
            $ priv_fotos = True
            $ n_hechos += 1
            $ puntos += 1
            if expuso_casa or expuso_colegio:
                show carolina neutro at personaje_normal
                narrador "Reviso mi perfil como si fuera un desconocido. Encuentro la foto de la puerta de mi casa y la del uniforme con el letrero. Las archivo."
                hide carolina neutro
            else:
                show carolina neutro at personaje_normal
                narrador "Reviso mi perfil como si fuera un desconocido. No hay mucho que esconder, pero encuentro una publicación de hace dos años con mi cumpleaños completo y el nombre del colegio en mi bio. La edito."
                hide carolina neutro
            show carolina hablando at personaje_normal
            carolina "Archivar sirve para que ya no se vean, sin perderlas. Pero que quede claro: si alguien ya las guardó, borrarlas no las desaparece de su celular. Por eso conviene pensar antes de subir."
            hide carolina
            jump h3_checkup

        "Activar la aprobación de etiquetas" if not priv_etiquetas:
            $ priv_etiquetas = True
            $ n_hechos += 1
            $ puntos += 1
            show carolina neutro at personaje_normal
            narrador "Activo la opción para aprobar manualmente cada vez que alguien me etiquete."
            chat "Valeria: perdón, yo te etiqueté en las fotos de la excursión, sin preguntar"
            hide carolina neutro
            show carolina hablando at personaje_normal
            carolina "Es justo para eso. Y al revés también: pidan permiso antes de etiquetar a otras personas."
            hide carolina hablando
            jump h3_checkup

        "Buscarme en internet como lo haría un desconocido" if not priv_busqueda:
            $ priv_busqueda = True
            $ n_hechos += 1
            $ puntos += 1
            show carolina neutro at personaje_normal
            narrador "Escribo mi nombre y el del colegio en el buscador, como haría alguien que no me conoce."
            narrador "Aparece mi perfil, una lista del equipo de básquet de hace dos años con mi nombre completo, y un foro de videojuegos donde usé el mismo nombre de usuario que en todo lo demás."
            hide carolina neutro
            show carolina hablando at personaje_normal
            carolina "Esto se llama huella digital: lo que tú dejas, lo que otros dejan de ti, y lo que se queda guardado aunque lo borres. No se puede borrar toda, pero sí se puede reducir y cuidar lo nuevo."
            carolina "Y un truco: no uses el mismo nombre de usuario en todas partes. Así es más difícil unir las piezas."
            hide carolina
            jump h3_checkup

        "Ya está, con eso basta" if n_hechos >= 2:
            show carolina neutro at personaje_normal
            jump h3_checkup_fin
            hide carolina neutro

    jump h3_checkup
    hide carolina pregunta

label h3_checkup_fin:

    if n_hechos >= 5:
        show carolina hablando at personaje_normal
        carolina "Lo hiciste todo. Eso no te hace invulnerable, pero cambia mucho el panorama."
        hide carolina hablando
    elif n_hechos >= 3:
        show carolina hablando at personaje_normal
        carolina "Buen avance. Lo que queda, hazlo esta semana, ¿sí? No lo dejes para después."
        hide carolina hablando
    else:
        show carolina hablando at personaje_normal
        carolina "Es un buen comienzo. Pero con tan pocos ajustes todavía quedan puertas abiertas, así que no lo dejes ahí."
        hide carolina hablando

    jump h3_final


# =====================================================================
#  EL FINAL
# =====================================================================
label h3_final:

    scene bg terraza with fade
    # play music "audio/final_calma.ogg" fadein 1.0

    narrador "Dos días después, en el recreo, nos sentamos los cuatro en la terraza."
    narrador "La plataforma retiró la publicación tras el reporte. No siempre pasa tan rápido, pero el reporte con las capturas ayuda. Y tener todo guardado nos dio más tranquilidad."

    if puntos >= 9:
        jump h3_final_bueno
        scene black with fade
        centered "Final bueno"
    elif puntos >= 4:
        jump h3_final_regular
        scene black with fade
        centered "Final regular"
    else:
        jump h3_final_malo
        scene black with fade
        centered "Final malo"


label h3_final_bueno:
    scene black with fade
    centered "Final bueno"

    show valeria hablando at personaje_normal
    valeria "Ya nadie la comparte. Y antes de etiquetar a alguien, ahora preguntamos."
    hide valeria hablando
    show mateo hablando at personaje_normal
    mateo "Hasta me puse a revisar mis propias fotos. Tenía una en mi bio con el nombre de mi calle, ¿puedes creerlo?"
    hide mateo hablando
    show mateo neutro at personaje_normal
    yo "Pues sí, a todos nos pasa."
    hide mateo neutro

    if familia_enterada:
        narrador "En casa conversamos largo. Mamá y yo acordamos revisar juntos mis redes cada cierto tiempo, sin regaños, solo para ponernos al día."

    narrador "FIN: Cuidar la privacidad no es esconderse. Es decidir qué compartes, con quién y con qué datos."
    jump h3_digi


label h3_final_regular:
    scene black with fade
    centered "Final regular"

    show sofia nerviosa at personaje_normal
    sofia "Mi cuenta ya la puse en privado también. Pero me da pereza revisar todo lo viejo."
    hide sofia nerviosa
    show mateo hablando at personaje_normal
    mateo "Pues empieza por lo que muestra dónde vives y dónde estudias. Lo demás puede esperar un poco."
    hide mateo hablando
    show mateo neutro at personaje_normal
    yo "Yo también me quedé a medias. Todavía me faltan cosas por cerrar."
    hide mateo neutro

    narrador "FIN: La publicación desapareció, pero algunas puertas siguen abiertas. Todavía hay tiempo de cerrarlas."
    jump h3_digi


label h3_final_malo:
    scene black with fade
    centered "Final malo"

    show valeria hablando at personaje_normal
    valeria "La publicación ya no está, pero hay gente que la guardó. Y tu cuenta sigue bastante abierta."
    hide valeria hablando
    show mateo hablando at personaje_normal
    mateo "Aún se puede arreglar. Pero hay que hacer los ajustes ya, y con apoyo."
    hide mateo hablando
    show mateo neutro at personaje_normal
    yo "Lo sé. Y se lo tengo que contar a mi familia."
    hide mateo neutro

    narrador "FIN: Lo que ya se compartió no siempre se puede recuperar. Pero lo que viene todavía lo puedes cuidar."
    jump h3_digi


# ---------------------------------------------------------------------
#  Cierre con Digi: resumen y opción de repetir
# ---------------------------------------------------------------------
label h3_digi:

    scene black with fade

    digi "¡Hola! Soy Digi. Antes de cerrar esta historia, te dejo cuatro cosas para llevarte."
    digi "Uno: antes de publicar, pregúntate qué datos estás regalando. El colegio, tu casa, tu rutina y tu cumpleaños dicen mucho de ti."
    digi "Dos: perfil privado, ubicación apagada y etiquetas aprobadas. Son tres ajustes que valen oro."
    digi "Tres: si alguien expone tus datos, no respondas con lo mismo. Guarda capturas con fecha y link, reporta, bloquea y cuéntale a un adulto de confianza."
    digi "Cuatro: lo que subes deja huella, aunque lo borres. Pregunta siempre antes de etiquetar a otras personas."

    menu:
        "¿Qué quieres hacer ahora?"

        "Volver a jugar esta historia":
            jump historia3

        "Terminar":
            return

    return
